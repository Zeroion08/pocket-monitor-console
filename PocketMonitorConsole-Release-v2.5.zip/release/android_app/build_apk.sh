#!/usr/bin/env bash
# 无 Gradle 手工构建：aapt2 -> javac -> d8 -> zipalign -> apksigner
set -e
cd "$(dirname "$0")"

JDK='D:\dev\android\jdk-17.0.21+9'
BT='D:\dev\android\sdk\build-tools\34.0.0'
AJ='D:\dev\android\sdk\platforms\android-34\android.jar'
export JAVA_HOME="$JDK"

AAPT="$BT/aapt2.exe"
JAVAC="$JDK/bin/javac.exe"
KEYTOOL="$JDK/bin/keytool.exe"
D8="$BT/d8.bat"
ZIPALIGN="$BT/zipalign.exe"
APKSIGNER="$BT/apksigner.bat"
PY="../.venv2/Scripts/python.exe"

rm -rf build
mkdir -p build/compiled build/gen build/classes build/dex

echo "[1/7] aapt2 compile res"
"$AAPT" compile --dir res -o build/compiled/res.zip

echo "[2/7] aapt2 link (manifest + resources + assets)"
"$AAPT" link -o build/base.apk \
    -I "$AJ" \
    --manifest AndroidManifest.xml \
    -R build/compiled/res.zip \
    -A assets \
    --java build/gen \
    --min-sdk-version 24 --target-sdk-version 34 \
    --auto-add-overlay

echo "[3/7] javac"
# 只编译 App 需要的类；DesktopTest / Dbg / PrepKey 是桌面验证工具，不进 APK
PKG=src/com/pocket/mimonitor
SRCS="$PKG/AdbConnection.java $PKG/AuthKeys.java $PKG/Monitor.java \
      $PKG/AppState.java $PKG/Ui.java $PKG/MainActivity.java \
      $(find build/gen -name 'R.java' | tr '\n' ' ')"
if ! "$JAVAC" -encoding UTF-8 -source 8 -target 8 \
        -cp "$AJ" -d build/classes $SRCS > build/javac.log 2>&1; then
    cat build/javac.log
    echo "javac FAILED" >&2
    exit 1
fi
grep -v "bootstrap class path" build/javac.log || true
# 关键类必须存在，防止 javac 部分成功后静默漏类
for c in MainActivity Ui AppState Monitor AdbConnection AuthKeys; do
    test -f "build/classes/com/pocket/mimonitor/$c.class" || {
        echo "missing class: $c" >&2; exit 1; }
done

echo "[4/7] d8 -> classes.dex"
CLASSES=$(find build/classes -name '*.class' | tr '\n' ' ')
"$D8" --lib "$AJ" --min-api 24 --output build/dex $CLASSES

echo "[5/7] 组装 APK"
"$PY" - << 'PYEOF'
import shutil, zipfile
shutil.copy('build/base.apk', 'build/unsigned.apk')
with zipfile.ZipFile('build/unsigned.apk', 'a', zipfile.ZIP_DEFLATED) as z:
    z.write('build/dex/classes.dex', 'classes.dex')
print('  classes.dex added, entries =',
      len(zipfile.ZipFile('build/unsigned.apk').namelist()))
PYEOF
"$ZIPALIGN" -f 4 build/unsigned.apk build/aligned.apk

echo "[6/7] 签名"
# 签名密钥必须长期保留，换证书会导致手机上无法覆盖安装
KS=app.keystore
if [ ! -f "$KS" ]; then
  "$KEYTOOL" -genkeypair -v -keystore "$KS" -alias pocket \
      -keyalg RSA -keysize 2048 -validity 10000 \
      -storepass pocket123 -keypass pocket123 \
      -dname "CN=Pocket Monitor, OU=Dev, O=Home, L=CN, ST=CN, C=CN" \
      > /dev/null 2>&1
fi
"$APKSIGNER" sign --ks "$KS" --ks-pass pass:pocket123 \
    --key-pass pass:pocket123 \
    --out PocketMonitorConsole.apk build/aligned.apk

echo "[7/7] 验证"
"$APKSIGNER" verify --verbose PocketMonitorConsole.apk | head -8
"$AAPT" dump badging PocketMonitorConsole.apk | head -6
cp PocketMonitorConsole.apk "红米显示器-手机控制台.apk"
ls -la *.apk
echo "BUILD OK"
