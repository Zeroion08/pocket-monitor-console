# -*- coding: utf-8 -*-
"""生成安卓启动图标：橙色圆角磁贴 + 白色 G（平头弧 + 矩形横杠 T 接，无接缝）。"""
import os
import struct
import sys
import zlib

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PyQt6.QtCore import QRectF, Qt
from PyQt6.QtGui import QColor, QImage, QPainter, QPainterPath, QPen

S = 512

def rounded_path(x, y, w, h, r):
    path = QPainterPath()
    path.addRoundedRect(QRectF(x, y, w, h), r, r)
    return path

def draw_icon(size):
    img = QImage(size, size, QImage.Format.Format_ARGB32)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    k = size / S

    # 橙色圆角磁贴
    tile = rounded_path(18 * k, 18 * k, S * k - 36 * k, S * k - 36 * k, 112 * k)
    p.fillPath(tile, QColor("#F2622F"))

    # 白色 G：平头弧（开口朝右上 45 度）+ 矩形横杠 T 接，无接缝
    cx = cy = size / 2
    r = 120 * k
    penw = 52 * k
    white = QColor("#FFFFFF")
    pen = QPen(white, penw, Qt.PenStyle.SolidLine,
               Qt.PenCapStyle.FlatCap, Qt.PenJoinStyle.MiterJoin)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawArc(QRectF(cx - r, cy - r, 2 * r, 2 * r), 45 * 16, 315 * 16)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(white)
    p.drawRect(QRectF(cx - r * 0.12, cy - penw / 2,
                      r * 1.12 + penw / 2, penw))

    p.end()
    return img

def png_bytes(img):
    w, h = img.width(), img.height()
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        for x in range(w):
            c = img.pixelColor(x, y)
            raw += bytes((c.red(), c.green(), c.blue(), c.alpha()))
    def chunk(tag, data):
        return (struct.pack(">I", len(data)) + tag + data +
                struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))
    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(raw), 9))
            + chunk(b"IEND", b""))

def main():
    from PyQt6.QtWidgets import QApplication
    app = QApplication(sys.argv)
    base = draw_icon(S)
    density_map = [
        ("mipmap-mdpi", 48),
        ("mipmap-hdpi", 72),
        ("mipmap-xhdpi", 96),
        ("mipmap-xxhdpi", 144),
        ("mipmap-xxxhdpi", 192),
    ]
    root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "res")
    for folder, px in density_map:
        im = base.scaled(px, px, Qt.AspectRatioMode.IgnoreAspectRatio,
                         Qt.TransformationMode.SmoothTransformation)
        data = png_bytes(im)
        out = os.path.join(root, folder, "ic_launcher.png")
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with open(out, "wb") as f:
            f.write(data)
        print(f"  {folder}/ic_launcher.png  {px}x{px}  {len(data)} bytes")
    print("done.")

if __name__ == "__main__":
    main()
