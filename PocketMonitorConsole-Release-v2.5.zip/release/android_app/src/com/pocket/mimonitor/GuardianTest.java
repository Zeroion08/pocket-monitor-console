package com.pocket.mimonitor;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Map;

/**
 * 桌面 JVM 真机测试（不打入 APK）：模拟"全新显示器"部署 ADB 保活守护。
 * 用法：java com.pocket.mimonitor.GuardianTest <ip> [--purge]
 *   --purge：先卸载守护再部署（模拟其他未安装保活的显示器）
 */
public class GuardianTest {
    public static void main(String[] args) throws Exception {
        String ip = args.length > 0 ? args[0] : "";
        if (ip.isEmpty()) {
            System.out.println("用法: GuardianTest <显示器IP> [--purge]");
            return;
        }
        boolean purge = args.length > 1 && "--purge".equals(args[1]);

        // 守护 APK 从 adb_guardian 资产目录取
        File guardianDir = new File("../minimal_ui/assets/adb_guardian");
        Monitor.AssetSource assets = new Monitor.AssetSource() {
            @Override
            public byte[] read(String name) throws IOException {
                File f = new File(guardianDir, name);
                return f.exists() ? Files.readAllBytes(f.toPath()) : null;
            }
        };

        java.nio.file.Path keyFile = new java.io.File("adb_key.txt").toPath();
        AuthKeys keys = new AuthKeys(new AuthKeys.Storage() {
            @Override
            public String loadKeys() {
                try {
                    return Files.exists(keyFile)
                            ? new String(Files.readAllBytes(keyFile), "UTF-8") : null;
                } catch (IOException e) {
                    return null;
                }
            }

            @Override
            public void saveKeys(String both) {
                try {
                    Files.write(keyFile, both.getBytes("UTF-8"));
                } catch (IOException ignored) {
                }
            }
        });

        try (AdbConnection conn = new AdbConnection(ip, 5555, 6000, keys)) {
            System.out.println("== 握手成功 ==");
            Monitor mon = new Monitor(conn, assets);

            System.out.println("== 部署前状态 ==");
            print(mon.guardianStatus());

            if (purge) {
                System.out.println("\n== 模拟全新显示器：卸载守护 ==");
                System.out.println(mon.shell(
                        "pm uninstall " + Monitor.GUARDIAN_PKG + " 2>&1").trim());
                // 顺带清掉辅助功能残留，彻底回到"别人的新显示器"状态
                mon.shell("settings put secure enabled_accessibility_services '' 2>/dev/null");
                System.out.println("卸载后状态 = ");
                print(mon.guardianStatus());
            }

            System.out.println("\n== ensureGuardian()（App 同款部署代码）==");
            long t0 = System.currentTimeMillis();
            Map<String, String> s = mon.ensureGuardian();
            long dt = System.currentTimeMillis() - t0;
            print(s);
            System.out.println("耗时 " + dt + " ms");
            System.out.println("guardianOk = " + Monitor.guardianOk(s));

            if (!Monitor.guardianOk(s)) {
                System.out.println("FAIL：部署后状态不完整");
                System.exit(1);
            }
            System.out.println("\n全新部署通过 ✅");
        }
        System.out.println("连接已关闭");
    }

    private static void print(Map<String, String> s) {
        for (Map.Entry<String, String> e : s.entrySet()) {
            String v = e.getValue();
            if (v.length() > 70) v = v.substring(0, 70) + "...";
            System.out.println("  " + e.getKey() + " = " + v);
        }
    }
}
