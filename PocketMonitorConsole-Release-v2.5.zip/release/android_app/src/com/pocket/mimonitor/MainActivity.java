package com.pocket.mimonitor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** 手机端极简控制台：主控台 / 画面 / 信号源 / 设置 四页。 */
public class MainActivity extends Activity {

    private static final String[] TAB_NAMES = {"主控台", "画面", "信号源", "设置"};

    private final LinearLayout[] pages = new LinearLayout[4];
    private final View[] pageViews = new View[4];
    private final TextView[] tabs = new TextView[4];
    private final View[] tabBars = new View[4];
    private final List<SliderSpec> sliders = new ArrayList<>();
    private final List<ChipSpec> chips = new ArrayList<>();

    private TextView statusDot, statusText, modelText, subText;
    private EditText ipEdit;
    private TextView connectBtn;
    private Switch lightSwitch;
    private LinearLayout modeRow;
    private TextView modeHintText;
    private TextView sdrMemText, hdrMemText;
    private TextView guardStatusText;
    private boolean currentHdr = false;
    private volatile boolean suppressMemory = false;
    private boolean suppress = false;
    private int currentTab = 0;

    // ---------------------------------------------------------------- 生命周期

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppState.init(this);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        setContentView(root);

        root.addView(buildHeader(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        FrameLayout body = new FrameLayout(this);
        for (int i = 0; i < 4; i++) {
            ScrollView sv = new ScrollView(this);
            sv.setVerticalScrollBarEnabled(false);
            pages[i] = Ui.page(this);
            sv.addView(pages[i], new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
            sv.setVisibility(i == 0 ? View.VISIBLE : View.GONE);
            pageViews[i] = sv;
            body.addView(sv, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
        }
        root.addView(body, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        root.addView(buildNav(), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        buildHome();
        buildPicture();
        buildSource();
        buildSettings();

        // 默认地址已内置，打开即用；失败只在状态栏提示，不打断用户
        String saved = AppState.getIp();
        ipEdit.setText(saved);
        doConnect(saved, true);
    }

    /** 从后台回来时静默探活：连接死了就自动重连，不弹窗不打扰。 */
    @Override
    protected void onResume() {
        super.onResume();
        if (AppState.isConnected() && AppState.hasEverConnected()) {
            // 发一条轻量命令探活；exec() 内部会自动重连并重试
            AppState.exec(new AppState.Task() {
                @Override
                public Object run(Monitor m) throws Exception {
                    m.connectAndRead();
                    return AppState.Snapshot.take(m);
                }
            }, new AppState.Cb() {
                @Override
                public void done(Object result, Exception err) {
                    if (err == null && result instanceof AppState.Snapshot) {
                        applySnapshot((AppState.Snapshot) result);
                        setStatus(true, "已连接");
                        connectBtn.setText("断开连接");
                        checkGuardian();
                    } else if (err instanceof AppState.ConnectionLostException) {
                        setStatus(false, "连接已断开");
                        connectBtn.setText("连接");
                    }
                }
            });
        }
    }

    // ---------------------------------------------------------------- 顶部 / 底部

    private View buildHeader() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(this, 16);
        h.setPadding(p, Ui.dp(this, 18), p, Ui.dp(this, 12));

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        TextView title = Ui.text(this, "红米 G Pro 27U", 20, Ui.TEXT, true);
        left.addView(title);
        subText = Ui.text(this, "极简控制台 · 手机端", 12, Ui.SUB, false);
        left.addView(subText);
        h.addView(left, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        LinearLayout badge = new LinearLayout(this);
        badge.setOrientation(LinearLayout.HORIZONTAL);
        badge.setGravity(Gravity.CENTER_VERTICAL);
        badge.setPadding(Ui.dp(this, 10), Ui.dp(this, 6),
                Ui.dp(this, 10), Ui.dp(this, 6));
        Ui.setCorner(badge, Ui.CARD_ALT, Ui.dp(this, 12));
        statusDot = Ui.text(this, "●", 11, Ui.SUB, false);
        statusDot.setPadding(0, 0, Ui.dp(this, 6), 0);
        badge.addView(statusDot);
        statusText = Ui.text(this, "未连接", 12, Ui.SUB, true);
        badge.addView(statusText);
        h.addView(badge);
        return h;
    }

    private View buildNav() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(Color.parseColor("#16191E"));
        nav.setPadding(Ui.dp(this, 6), Ui.dp(this, 8),
                Ui.dp(this, 6), Ui.dp(this, 10));
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 4));

            View bar = new View(this);
            Ui.setCorner(bar, i == 0 ? Ui.ACCENT : Color.TRANSPARENT, Ui.dp(this, 2));
            LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                    Ui.dp(this, 22), Ui.dp(this, 3));
            blp.gravity = Gravity.CENTER_HORIZONTAL;
            blp.bottomMargin = Ui.dp(this, 7);
            item.addView(bar, blp);

            TextView label = Ui.text(this, TAB_NAMES[i], 12,
                    i == 0 ? Ui.ACCENT : Ui.SUB, i == 0);
            label.setGravity(Gravity.CENTER);
            // 垂直 LinearLayout 默认子项宽度 MATCH_PARENT，文字会贴左而非居中，必须显式 WRAP_CONTENT
            LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            llp.gravity = Gravity.CENTER_HORIZONTAL;
            item.addView(label, llp);
            tabs[i] = label;
            tabBars[i] = bar;
            item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    switchTab(idx);
                }
            });
            nav.addView(item, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        }
        return nav;
    }

    private void switchTab(int idx) {
        currentTab = idx;
        for (int i = 0; i < 4; i++) {
            pageViews[i].setVisibility(i == idx ? View.VISIBLE : View.GONE);
            tabs[i].setTextColor(i == idx ? Ui.ACCENT : Ui.SUB);
            tabs[i].setTypeface(i == idx ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            View bar = tabBars[i];
            if (bar != null) {
                Ui.setCorner(bar, i == idx ? Ui.ACCENT : Color.TRANSPARENT,
                        Ui.dp(this, 2));
            }
        }
    }

    // ---------------------------------------------------------------- 页面 0：主控台

    private void buildHome() {
        LinearLayout pg = pages[0];

        LinearLayout dev = Ui.card(this);
        dev.addView(Ui.hint(this, "当前设备"));
        modelText = Ui.text(this, "尚未连接", 19, Ui.TEXT, true);
        modelText.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 4));
        dev.addView(modelText);
        TextView tip = Ui.hint(this, "同一 WiFi · ADB 5555 · 无需电脑");
        dev.addView(tip);
        TextView refresh = Ui.bigButton(this, "重新读取状态", false);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = Ui.dp(this, 12);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshState();
            }
        });
        dev.addView(refresh, rlp);
        pg.addView(dev, Ui.cardLp(this));

        addSlider(pg, 0, "亮度", "backlight", 1, 100, 100);

        // 主控台第二项改为精密控光（4 档枚举，不用滑杆）
        Monitor.ParamDef dim = Monitor.paramDef("picture_local_dimming");
        LinearLayout dimCard = Ui.card(this);
        dimCard.addView(Ui.title(this, "精密控光"));
        LinearLayout dimRow = Ui.chipRow(this, dim.names, 0);
        dimRow.setLayoutParams(withTop(Ui.dp(this, 12)));
        dimCard.addView(dimRow);
        pg.addView(dimCard, Ui.cardLp(this));
        chips.add(new ChipSpec("param", dim.key, dim.values, dimRow));
        bindChips(dimRow, dim.values, "param", dim.key);

        LinearLayout modeCard = Ui.card(this);
        modeCard.addView(Ui.title(this, "图像模式"));
        modeHintText = Ui.hint(this, "当前信号：检测中…");
        modeCard.addView(modeHintText, withTop(Ui.dp(this, 4)));
        modeRow = Ui.chipRow(this, Monitor.MODE_NAMES, 0);
        modeRow.setLayoutParams(withTop(Ui.dp(this, 12)));
        modeCard.addView(modeRow);
        pg.addView(modeCard, Ui.cardLp(this));
        bindModes(modeRow);

        LinearLayout quick = Ui.card(this);
        quick.addView(Ui.title(this, "快捷控制"));
        LinearLayout swRow = new LinearLayout(this);
        swRow.setOrientation(LinearLayout.HORIZONTAL);
        swRow.setGravity(Gravity.CENTER_VERTICAL);
        swRow.setLayoutParams(withTop(Ui.dp(this, 8)));
        TextView swLabel = Ui.text(this, "自动感光", 14, Ui.TEXT, false);
        swRow.addView(swLabel, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        lightSwitch = new Switch(this);
        lightSwitch.setThumbTintList(
                android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        lightSwitch.setTrackTintList(
                android.content.res.ColorStateList.valueOf(Ui.LINE));
        swRow.addView(lightSwitch);
        quick.addView(swRow);
        lightSwitch.setOnCheckedChangeListener(
                new android.widget.CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(
                            android.widget.CompoundButton b, final boolean on) {
                        if (suppress) return;
                        runCmd(new AppState.Task() {
                            @Override
                            public Object run(Monitor m) throws Exception {
                                m.setLightSensor(on);
                                return null;
                            }
                        }, "感光已" + (on ? "开启" : "关闭"));
                    }
                });

        LinearLayout keys = new LinearLayout(this);
        keys.setOrientation(LinearLayout.HORIZONTAL);
        keys.setLayoutParams(withTop(Ui.dp(this, 14)));
        TextView volDown = Ui.bigButton(this, "音量 −", false);
        TextView volUp = Ui.bigButton(this, "音量 +", false);
        TextView power = Ui.bigButton(this, "电源", false);
        LinearLayout.LayoutParams klp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        klp.rightMargin = Ui.dp(this, 8);
        keys.addView(volDown, klp);
        LinearLayout.LayoutParams klp2 = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        klp2.rightMargin = Ui.dp(this, 8);
        keys.addView(volUp, klp2);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        keys.addView(power, plp);
        quick.addView(keys);
        // 符号键名与桌面版一致，避免部分 MiTV 固件对数字键码解析相反
        volDown.setOnClickListener(keyClick("KEYCODE_VOLUME_DOWN"));
        volUp.setOnClickListener(keyClick("KEYCODE_VOLUME_UP"));
        power.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("电源")
                        .setMessage("让显示器进入待机 / 唤醒？")
                        .setNegativeButton("取消", null)
                        .setPositiveButton("确定", (d, w) -> runCmd(m -> {
                            m.power();
                            return null;
                        }, "已发送电源键"))
                        .show();
            }
        });
        pg.addView(quick, Ui.cardLp(this));
    }

    private View.OnClickListener keyClick(final String keyName) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runCmd(new AppState.Task() {
                    @Override
                    public Object run(Monitor m) throws Exception {
                        m.key(keyName);
                        return null;
                    }
                }, null);
            }
        };
    }

    // ---------------------------------------------------------------- 页面 1：画面

    private void buildPicture() {
        LinearLayout pg = pages[1];
        TextView cap = Ui.hint(this, "拖动滑杆后松手即生效 · 参数即时下发");
        cap.setPadding(Ui.dp(this, 4), 0, 0, Ui.dp(this, 8));
        pg.addView(cap);

        addSlider(pg, 1, "亮度", "backlight", 1, 100, 100);
        addSlider(pg, 1, "黑电平", "black_level", 0, 100, 50);
        addSlider(pg, 1, "对比度", "contrast", 0, 100, 50);
        addSlider(pg, 1, "饱和度", "saturation", 0, 100, 50);
        addSlider(pg, 1, "色调", "hue", 0, 100, 50);
        addSlider(pg, 1, "锐度", "sharpness", 0, 100, 1);

        for (Monitor.ParamDef def : Monitor.PARAMS) {
            LinearLayout card = Ui.card(this);
            card.addView(Ui.title(this, def.label));
            int selected = 0;
            LinearLayout grid = Ui.chipGrid(this, def.names, selected, 3);
            grid.setLayoutParams(withTop(Ui.dp(this, 12)));
            card.addView(grid);
            pg.addView(card, Ui.cardLp(this));
            chips.add(new ChipSpec("param", def.key, def.values, grid));
            bindChips(grid, def.values, "param", def.key);
        }
    }

    // ---------------------------------------------------------------- 页面 2：信号源

    private void buildSource() {
        LinearLayout pg = pages[2];
        LinearLayout card = Ui.card(this);
        card.addView(Ui.title(this, "输入信号源"));
        card.addView(Ui.hint(this, "切换会重启播放器，属正常现象"),
                withTop(Ui.dp(this, 4)));

        LinearLayout grid = Ui.chipGrid(this, Monitor.SOURCE_NAMES, 0, 2);
        grid.setLayoutParams(withTop(Ui.dp(this, 14)));
        // 信号源按钮做高一点
        for (int r = 0; r < grid.getChildCount(); r++) {
            View row = grid.getChildAt(r);
            if (row instanceof LinearLayout) {
                LinearLayout lr = (LinearLayout) row;
                for (int i = 0; i < lr.getChildCount(); i++) {
                    View child = lr.getChildAt(i);
                    if (child instanceof TextView) {
                        ((TextView) child).setTextSize(16);
                        child.setPadding(Ui.dp(this, 10), Ui.dp(this, 20),
                                Ui.dp(this, 10), Ui.dp(this, 20));
                    }
                }
            }
        }
        card.addView(grid);
        pg.addView(card, Ui.cardLp(this));
        int[] vals = {23, 24, 29, 30};
        chips.add(new ChipSpec("source", null, vals, grid));
        bindChips(grid, vals, "source", null);

        TextView note = Ui.hint(this,
                "提示：切换后显示器需要 1~3 秒重新握手信号，期间黑屏属正常。");
        note.setPadding(Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 6), 0);
        pg.addView(note);
    }

    // ---------------------------------------------------------------- 页面 3：设置

    private void buildSettings() {
        LinearLayout pg = pages[3];

        LinearLayout conn = Ui.card(this);
        conn.addView(Ui.title(this, "连接显示器"));
        conn.addView(Ui.hint(this, "显示器 IP 地址（在电视 网络设置 里查看）"),
                withTop(Ui.dp(this, 4)));

        ipEdit = new EditText(this);
        ipEdit.setHint("例如 192.168.1.8");
        ipEdit.setTextColor(Ui.TEXT);
        ipEdit.setHintTextColor(Ui.SUB);
        ipEdit.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_URI);
        ipEdit.setSingleLine(true);
        ipEdit.setPadding(Ui.dp(this, 12), Ui.dp(this, 12),
                Ui.dp(this, 12), Ui.dp(this, 12));
        Ui.setCorner(ipEdit, Ui.CARD_ALT, Ui.dp(this, 12));
        conn.addView(ipEdit, withTop(Ui.dp(this, 12)));

        connectBtn = Ui.bigButton(this, "连接", true);
        connectBtn.setLayoutParams(withTop(Ui.dp(this, 12)));
        connectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (AppState.isConnected()) {
                    AppState.disconnect(new AppState.Cb() {
                        @Override
                        public void done(Object r, Exception e) {
                            setStatus(false, "已断开");
                            connectBtn.setText("连接");
                        }
                    });
                } else {
                    String ip = ipEdit.getText().toString().trim();
                    if (ip.isEmpty()) {
                        toast("请先填写显示器 IP");
                        return;
                    }
                    doConnect(ip, false);
                }
            }
        });
        conn.addView(connectBtn);
        pg.addView(conn, Ui.cardLp(this));

        // HDR/SDR 精密控光记忆：与桌面版 local_dimming_memory 一致，按信号档位分别记忆
        LinearLayout mem = Ui.card(this);
        mem.addView(Ui.title(this, "HDR/SDR 精密控光记忆"));
        mem.addView(Ui.hint(this, "按显示器当前 HDR/SDR 模式自动切换精密控光"),
                withTop(Ui.dp(this, 4)));
        LinearLayout swRow = new LinearLayout(this);
        swRow.setOrientation(LinearLayout.HORIZONTAL);
        swRow.setGravity(Gravity.CENTER_VERTICAL);
        swRow.setLayoutParams(withTop(Ui.dp(this, 10)));
        swRow.addView(Ui.text(this, "自动切换", 14, Ui.TEXT, false),
                new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        final Switch memSwitch = new Switch(this);
        memSwitch.setChecked(AppState.isHdrMemoryEnabled());
        memSwitch.setThumbTintList(
                android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        memSwitch.setTrackTintList(
                android.content.res.ColorStateList.valueOf(Ui.LINE));
        swRow.addView(memSwitch);
        mem.addView(swRow);
        memSwitch.setOnCheckedChangeListener((b, on) -> {
            AppState.setHdrMemoryEnabled(on);
            updateMemText();
            if (on) {
                runCmd(m -> {
                    applyDimmingMemory(m, null);
                    return null;
                }, "记忆已开启，已应用当前档位");
            }
        });

        LinearLayout memRow = new LinearLayout(this);
        memRow.setOrientation(LinearLayout.HORIZONTAL);
        memRow.setLayoutParams(withTop(Ui.dp(this, 12)));
        sdrMemText = Ui.bigButton(this, "", false);
        hdrMemText = Ui.bigButton(this, "", false);
        memRow.addView(sdrMemText, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        hlp.leftMargin = Ui.dp(this, 8);
        memRow.addView(hdrMemText, hlp);
        mem.addView(memRow);
        sdrMemText.setOnClickListener(v -> cycleDimmingMemory(false));
        hdrMemText.setOnClickListener(v -> cycleDimmingMemory(true));
        mem.addView(Ui.hint(this, "点击上方按钮循环：关 → 低 → 中 → 高"),
                withTop(Ui.dp(this, 10)));
        updateMemText();
        pg.addView(mem, Ui.cardLp(this));

        // ADB 保活守护：防止显示器重启后 ADB 自动关闭
        LinearLayout guard = Ui.card(this);
        guard.addView(Ui.title(this, "ADB 保活守护"));
        guard.addView(Ui.hint(this, "部署到显示器后，重启/待机唤醒不再丢 ADB"),
                withTop(Ui.dp(this, 4)));
        guardStatusText = Ui.text(this, "状态：未检测", 13, Ui.SUB, false);
        guardStatusText.setPadding(0, Ui.dp(this, 10), 0, 0);
        guard.addView(guardStatusText);
        TextView deployBtn = Ui.bigButton(this, "一键部署 / 修复", true);
        deployBtn.setLayoutParams(withTop(Ui.dp(this, 12)));
        deployBtn.setOnClickListener(v -> deployGuardian());
        guard.addView(deployBtn);
        pg.addView(guard, Ui.cardLp(this));

        LinearLayout about = Ui.card(this);
        about.addView(Ui.title(this, "关于"));
        about.addView(Ui.text(this,
                "手机端直接通过 ADB 协议连接显示器 5555 端口，不依赖电脑、"
                        + "不需要在手机上安装 ADB 工具。\n\n"
                        + "APK 内置了已在显示器上授权的调试密钥，装好即可连接。\n\n"
                        + "若显示器恢复出厂设置导致连接被拒，请在显示器弹出的"
                        + "「允许 USB 调试吗？」对话框中勾选「一律允许」并确认。",
                13, Ui.SUB, false), withTop(Ui.dp(this, 8)));
        pg.addView(about, Ui.cardLp(this));

        LinearLayout ver = Ui.card(this);
        ver.addView(Ui.title(this, "版本"));
        ver.addView(Ui.hint(this, "Pocket Monitor Console 2.5 · ADB 保活 + HDR/SDR 记忆"),
                withTop(Ui.dp(this, 6)));
        pg.addView(ver, Ui.cardLp(this));
    }

    // ---------------------------------------------------------------- 控件构造 / 绑定

    private static class SliderSpec {
        String key;
        int min, max;
        SeekBar bar;
    }

    private static class ChipSpec {
        String kind, key;
        int[] values;
        LinearLayout box;

        ChipSpec(String kind, String key, int[] values, LinearLayout box) {
            this.kind = kind;
            this.key = key;
            this.values = values;
            this.box = box;
        }
    }

    private LinearLayout.LayoutParams withTop(int px) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = px;
        return lp;
    }

    private void addSlider(LinearLayout page, int pageIndex, String label,
                           String key, int min, int max, int initial) {
        final SliderSpec spec = new SliderSpec();
        spec.key = key;
        spec.min = min;
        spec.max = max;
        LinearLayout card = Ui.sliderCard(this, label, min, max, initial,
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar s) {
                    }

                    @Override
                    public void onStopTrackingTouch(final SeekBar s) {
                        Object tag = s.getTag();
                        if (!(tag instanceof SliderSpec)) return;
                        final SliderSpec sp = (SliderSpec) tag;
                        final int v = s.getProgress() + sp.min;
                        runCmd(new AppState.Task() {
                            @Override
                            public Object run(Monitor m) throws Exception {
                                m.setSlider(sp.key, v);
                                return null;
                            }
                        }, null);
                    }
                });
        spec.bar = Ui.barOf(card);
        if (spec.bar != null) spec.bar.setTag(spec);
        sliders.add(spec);
        page.addView(card, Ui.cardLp(this));
    }

    // ---------------- 图像模式：HDR/SDR 分档 ----------------

    private void bindModes(final LinearLayout box) {
        List<TextView> list = collectChips(box);
        for (int i = 0; i < list.size(); i++) {
            final int slot = i;
            list.get(i).setOnClickListener(v -> {
                if (!AppState.isConnected()) {
                    toast("请先连接显示器");
                    return;
                }
                final int val = currentHdr ? Monitor.MODE_HDR[slot]
                        : Monitor.MODE_SDR[slot];
                paintChips(box, slot);
                runCmd(m -> {
                    m.setMode(val);
                    applyDimmingMemory(m, null);
                    return null;
                }, null);
                updateModeCard(Monitor.isHdrMode(val), slot);
            });
        }
    }

    private void updateModeCard(boolean hdr, int selectedSlot) {
        currentHdr = hdr;
        modeHintText.setText(hdr
                ? "当前：HDR 模式 · 标准/游戏/电影 → HDR 显示器/游戏/电影"
                : "当前：SDR 模式 · 标准/游戏/电影 → 标准/游戏/电影");
        if (selectedSlot >= 0 && modeRow != null) paintChips(modeRow, selectedSlot);
    }

    // ---------------- HDR/SDR 精密控光记忆 ----------------

    /** 在 worker 线程调用：按当前（或指定）信号档位应用记忆值，并抑制回写。 */
    private void applyDimmingMemory(Monitor m, Boolean hdrOverride) {
        if (!AppState.isHdrMemoryEnabled()) return;
        boolean hdr = hdrOverride != null ? hdrOverride : m.isHdr;
        int v = AppState.getDimmingMemory(hdr);
        if (v < 0 || v > 3) return;
        Integer cur = m.paramValues.get("picture_local_dimming");
        if (cur != null && cur == v) return;
        suppressMemory = true;
        try {
            m.setParam("picture_local_dimming", v);
        } catch (Exception ignored) {
        } finally {
            suppressMemory = false;
        }
    }

    private void cycleDimmingMemory(boolean hdr) {
        int cur = AppState.getDimmingMemory(hdr);
        AppState.setDimmingMemory(hdr, (cur + 1) % 4);
        updateMemText();
        toast((hdr ? "HDR" : "SDR") + " 精密控光记忆已更新");
        if (AppState.isHdrMemoryEnabled() && hdr == currentHdr) {
            runCmd(m -> {
                applyDimmingMemory(m, hdr);
                return null;
            }, null);
        }
    }

    private void updateMemText() {
        if (sdrMemText == null || hdrMemText == null) return;
        String[] names = {"关", "低", "中", "高"};
        int s = AppState.getDimmingMemory(false);
        int h = AppState.getDimmingMemory(true);
        sdrMemText.setText("SDR：" + (s < 0 ? "未设置" : names[s]));
        hdrMemText.setText("HDR：" + (h < 0 ? "未设置" : names[h]));
    }

    private void bindChips(LinearLayout box, final int[] values,
                           final String kind, final String key) {
        List<TextView> list = collectChips(box);
        for (int i = 0; i < list.size(); i++) {
            final int idx = i;
            final int value = i < values.length ? values[i] : -1;
            list.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (!AppState.isConnected()) {
                        toast("请先连接显示器");
                        return;
                    }
                    paintChips(box, idx);
                    runCmd(new AppState.Task() {
                        @Override
                        public Object run(Monitor m) throws Exception {
                            if ("source".equals(kind)) m.setSource(value);
                            else {
                                m.setParam(key, value);
                                // 手动改精密控光时，把当前信号档位的值记进对应 bucket
                                if ("picture_local_dimming".equals(key)
                                        && AppState.isHdrMemoryEnabled()
                                        && !suppressMemory) {
                                    AppState.setDimmingMemory(m.isHdr, value);
                                    runOnUiThread(() -> updateMemText());
                                }
                            }
                            return null;
                        }
                    }, null, (result, err) -> {
                        if (err == null && "param".equals(kind)) {
                            // 主控台与画面页共用同一参数时，两处高亮同步
                            for (ChipSpec other : chips) {
                                if ("param".equals(other.kind) && key.equals(other.key)) {
                                    paintChips(other.box, idx);
                                }
                            }
                        }
                    });
                }
            });
        }
    }

    private List<TextView> collectChips(LinearLayout box) {
        List<TextView> out = new ArrayList<>();
        for (int r = 0; r < box.getChildCount(); r++) {
            View row = box.getChildAt(r);
            if (row instanceof TextView) {          // chipRow：单行直接放 TextView
                out.add((TextView) row);
                continue;
            }
            if (!(row instanceof LinearLayout)) continue;
            LinearLayout lr = (LinearLayout) row;
            for (int i = 0; i < lr.getChildCount(); i++) {
                View child = lr.getChildAt(i);
                if (child instanceof TextView) out.add((TextView) child);
            }
        }
        return out;
    }

    private void paintChips(LinearLayout box, int selected) {
        List<TextView> list = collectChips(box);
        for (int i = 0; i < list.size(); i++) {
            TextView t = list.get(i);
            boolean on = i == selected;
            t.setTextColor(on ? Color.WHITE : Ui.SUB);
            t.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            Ui.setCorner(t, on ? Ui.ACCENT : Ui.CARD_ALT, Ui.dp(this, 11));
        }
    }

    // ---------------------------------------------------------------- 连接 / 状态

    private void doConnect(final String ip) {
        doConnect(ip, false);
    }

    private void doConnect(final String ip, final boolean silent) {
        setStatus(false, "连接中…");
        connectBtn.setText("连接中…");
        AppState.connect(ip, new AppState.Cb() {
            @Override
            public void done(Object result, Exception err) {
                if (err != null) {
                    setStatus(false, "连接失败");
                    connectBtn.setText("连接");
                    modelText.setText("连接失败");
                    if (!silent) {
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle("无法连接显示器")
                                .setMessage(err.getMessage()
                                        + "\n\n请确认：手机与显示器在同一 WiFi、"
                                        + "显示器已开启 ADB 调试、IP 填写正确。")
                                .setPositiveButton("知道了", null)
                                .show();
                    } else {
                        toast("连接失败，可在设置页修改 IP 后重试");
                    }
                    return;
                }
                AppState.Snapshot s = (AppState.Snapshot) result;
                applySnapshot(s);
                setStatus(true, "已连接");
                connectBtn.setText("断开连接");
                modelText.setText(s.model == null || s.model.isEmpty()
                        ? "MiTV 显示器" : s.model);
                subText.setText("已连接 · " + ip + ":5555");
                toast("连接成功，状态已同步");
                checkGuardian();
            }
        });
    }

    private void refreshState() {
        if (!AppState.isConnected()) {
            toast("请先连接显示器");
            return;
        }
        runCmd(new AppState.Task() {
            @Override
            public Object run(Monitor m) throws Exception {
                m.connectAndRead();
                return AppState.Snapshot.take(m);
            }
        }, null, new AppState.Cb() {
            @Override
            public void done(Object result, Exception err) {
                if (err == null && result instanceof AppState.Snapshot) {
                    applySnapshot((AppState.Snapshot) result);
                    toast("状态已刷新");
                }
            }
        });
    }

    // ---------------------------------------------------------------- ADB 保活守护

    private void deployGuardian() {
        if (!AppState.isConnected()) {
            toast("请先连接显示器");
            return;
        }
        guardStatusText.setText("状态：正在部署…");
        guardStatusText.setTextColor(Ui.SUB);
        runCmd(m -> m.ensureGuardian(), "ADB 保活守护已部署", (result, err) -> {
            if (err == null && result instanceof Map) {
                applyGuardianStatus((Map<String, String>) result);
            } else if (err != null) {
                guardStatusText.setText("状态：部署失败 - " + err.getMessage());
                guardStatusText.setTextColor(Color.parseColor("#FF6B5F"));
            }
        });
    }

    private void checkGuardian() {
        if (!AppState.isConnected()) return;
        AppState.exec(m -> m.guardianStatus(), (result, err) -> {
            if (err == null && result instanceof Map) {
                applyGuardianStatus((Map<String, String>) result);
            }
        });
    }

    @SuppressWarnings("unchecked")
    private void applyGuardianStatus(Map<String, String> s) {
        boolean ok = Monitor.guardianOk(s);
        boolean installed = s.getOrDefault("I", "").contains(Monitor.GUARDIAN_PKG);
        if (ok) {
            guardStatusText.setText("状态：正常运行，ADB 保活已启用");
            guardStatusText.setTextColor(Color.parseColor("#20C46B"));
            return;
        }
        if (!installed) {
            guardStatusText.setText("状态：未安装 AdbGuardian");
            guardStatusText.setTextColor(Color.parseColor("#FF6B5F"));
            return;
        }
        StringBuilder miss = new StringBuilder();
        if (s.getOrDefault("P", "").isEmpty()) miss.append("进程未运行");
        if (!s.getOrDefault("C", "").contains(Monitor.GUARDIAN_A11Y)) {
            if (miss.length() > 0) miss.append("，");
            miss.append("辅助功能未启用");
        }
        if (!"-134250497".equals(s.get("M"))) {
            if (miss.length() > 0) miss.append("，");
            miss.append("休眠保护未写入");
        }
        if (!"1".equals(s.get("A")) || !"1".equals(s.get("W"))) {
            if (miss.length() > 0) miss.append("，");
            miss.append("ADB 开关异常");
        }
        if (!"5555".equals(s.get("S")) || !"5555".equals(s.get("R"))) {
            if (miss.length() > 0) miss.append("，");
            miss.append("端口异常");
        }
        guardStatusText.setText("状态：" + (miss.length() > 0 ? miss : "已安装，等待复检"));
        guardStatusText.setTextColor(Color.parseColor("#D89614"));
    }

    private void applySnapshot(AppState.Snapshot s) {
        suppress = true;
        updateModeCard(s.hdr, Monitor.modeSlot(s.mode));
        for (SliderSpec spec : sliders) {
            Integer v = s.sliders.get(spec.key);
            if (v != null && spec.bar != null) {
                spec.bar.setProgress(Math.max(0,
                        Math.min(spec.max - spec.min, v - spec.min)));
            }
        }
        for (ChipSpec c : chips) {
            int cur = -1;
            if ("source".equals(c.kind)) cur = s.source;
            else {
                Integer v = s.params.get(c.key);
                cur = v == null ? Integer.MIN_VALUE : v;
            }
            int idx = -1;
            for (int i = 0; i < c.values.length; i++) {
                if (c.values[i] == cur) {
                    idx = i;
                    break;
                }
            }
            if (idx >= 0) paintChips(c.box, idx);
        }
        lightSwitch.setChecked(s.lightSensor == 1);
        suppress = false;
    }

    private void setStatus(boolean on, String label) {
        statusDot.setTextColor(on ? Ui.ACCENT : Ui.SUB);
        statusText.setText(label);
        statusText.setTextColor(on ? Ui.ACCENT : Ui.SUB);
    }

    private void runCmd(AppState.Task task, final String okMsg) {
        runCmd(task, okMsg, null);
    }

    private void runCmd(AppState.Task task, final String okMsg, final AppState.Cb extra) {
        AppState.exec(task, new AppState.Cb() {
            @Override
            public void done(Object result, Exception err) {
                if (err != null) {
                    if (err instanceof AppState.ConnectionLostException) {
                        setStatus(false, "连接已断开");
                        connectBtn.setText("连接");
                        toast("连接已断开，点击「连接」重试");
                    } else {
                        toast("命令失败：" + err.getMessage());
                    }
                } else if (okMsg != null) {
                    toast(okMsg);
                }
                if (extra != null) extra.done(result, err);
            }
        });
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
