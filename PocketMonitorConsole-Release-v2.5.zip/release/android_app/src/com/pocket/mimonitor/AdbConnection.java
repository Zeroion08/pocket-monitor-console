package com.pocket.mimonitor;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.zip.CRC32;

/**
 * 纯 Java 实现的 ADB 客户端线协议（对齐桌面版 adb.exe 的行为）。
 * 直接连接显示器的 adbd (TCP 5555)，不依赖任何本地 ADB server。
 *
 * 支持的能力：
 *  - CNXN 握手（无鉴权路径；若设备要求 AUTH 会抛出带说明的异常）
 *  - shell:<command> 服务（v1 流，stdout/stderr 合并，读到 CLSE 结束）
 *  - sync: 服务（SEND/DATA/DONE 推送文件，读取 OKAY/FAIL）
 */
public class AdbConnection implements AutoCloseable {

    private static final int A_SYNC = 0x434e5953;   // "SYNC"
    private static final int A_CNXN = 0x4e584e43;   // "CNXN"
    private static final int A_AUTH = 0x48545541;   // "AUTH"
    private static final int A_OPEN = 0x4e45504f;   // "OPEN"
    private static final int A_OKAY = 0x59414b4f;   // "OKAY"
    private static final int A_CLSE = 0x45534c43;   // "CLSE"
    private static final int A_WRTE = 0x45545257;   // "WRTE"

    private static final int MAX_DATA = 1 << 18;    // 256 KB

    /** 调试开关（桌面测试用）。 */
    public static volatile boolean debug = false;

    private final Socket socket;
    private final DataInputStream in;
    private final DataOutputStream out;
    private final int localId = 0x11223300;
    private int nextLocal = 1;
    private int remoteMax = 4096;
    private boolean closed = false;

    public AdbConnection(String host, int port, int timeoutMs, AuthKeys keys)
            throws IOException {
        socket = new Socket();
        socket.connect(new InetSocketAddress(host, port), timeoutMs);
        socket.setSoTimeout(timeoutMs);
        socket.setTcpNoDelay(true);
        in = new DataInputStream(socket.getInputStream());
        out = new DataOutputStream(socket.getOutputStream());
        handshake(keys);
    }

    public AdbConnection(String host, int port, int timeoutMs) throws IOException {
        this(host, port, timeoutMs, null);
    }

    // ------------------------------------------------------------ 线协议底层

    private static int crc32(byte[] payload, int len) {
        CRC32 c = new CRC32();
        c.update(payload, 0, len);
        return (int) c.getValue();
    }

    private void writeMsg(int cmd, int arg0, int arg1, byte[] payload, int len)
            throws IOException {
        out.writeInt(Integer.reverseBytes(cmd));
        out.writeInt(Integer.reverseBytes(arg0));
        out.writeInt(Integer.reverseBytes(arg1));
        out.writeInt(Integer.reverseBytes(len));
        out.writeInt(Integer.reverseBytes(crc32(payload, len)));
        out.writeInt(Integer.reverseBytes(cmd ^ 0xFFFFFFFF));
        if (len > 0) {
            out.write(payload, 0, len);
        }
        out.flush();
    }

    private static final class Msg {
        int cmd, arg0, arg1, len;
        byte[] payload;
    }

    private Msg readMsg() throws IOException {
        Msg m = new Msg();
        m.cmd = Integer.reverseBytes(in.readInt());
        m.arg0 = Integer.reverseBytes(in.readInt());
        m.arg1 = Integer.reverseBytes(in.readInt());
        m.len = Integer.reverseBytes(in.readInt());
        in.readInt();           // crc
        in.readInt();           // magic
        m.payload = new byte[Math.max(0, m.len)];
        in.readFully(m.payload);
        return m;
    }

    private void handshake(AuthKeys keys) throws IOException {
        // 等价于 adb connect：CNXN(version, maxdata, "host::\0")
        byte[] ident = "host::\0".getBytes("UTF-8");
        writeMsg(A_CNXN, 0x01000001, MAX_DATA, ident, ident.length);
        boolean sentSignature = false;
        boolean sentPublicKey = false;
        int rounds = 0;
        while (true) {
            Msg m = readMsg();
            if (debug) {
                System.out.println("[adb] recv cmd=0x" + Integer.toHexString(m.cmd)
                        + " arg0=" + m.arg0 + " len=" + m.len);
            }
            rounds++;
            if (rounds > 8) {
                close();
                throw new IOException("ADB 认证握手循环过多");
            }
            if (m.cmd == A_CNXN) {
                if (m.arg1 > 0 && m.arg1 < remoteMax) {
                    remoteMax = m.arg1;
                }
                return;
            }
            if (m.cmd == A_AUTH) {
                if (m.arg0 == 1) {              // AUTH RSATOKEN：20 字节挑战
                    if (keys != null && !sentSignature) {
                        byte[] sig = keys.signToken(m.payload);
                        if (sig != null) {
                            writeMsg(A_AUTH, 2, 0, sig, sig.length);
                            sentSignature = true;
                            continue;
                        }
                    }
                    if (keys != null && !sentPublicKey) {
                        byte[] pub = keys.androidPublicKeyPayload();
                        writeMsg(A_AUTH, 3, 0, pub, pub.length);
                        sentPublicKey = true;
                        continue;
                    }
                    close();
                    throw new IOException("ADB 授权失败：设备要求密钥授权，"
                            + "且公钥未被接受（若首次使用请在电视上确认授权弹窗）");
                }
                // arg0 == 2：要求签名之外的罕见类型——发公钥
                if (keys != null && !sentPublicKey) {
                    byte[] pub = keys.androidPublicKeyPayload();
                    writeMsg(A_AUTH, 3, 0, pub, pub.length);
                    sentPublicKey = true;
                    continue;
                }
                close();
                throw new IOException("ADB 认证被拒绝");
            }
            close();
            throw new IOException("CNXN 握手收到意外消息：0x"
                    + Integer.toHexString(m.cmd));
        }
    }

    // ------------------------------------------------------------ shell 服务

    /** 执行一条 shell 命令并收集全部输出（stdout/stderr 合并）。 */
    public synchronized String shell(String command) throws IOException {
        int lid = nextLocal++;
        byte[] payload = ("shell:" + command + "\0").getBytes("UTF-8");
        if (payload.length > remoteMax) {
            throw new IOException("命令过长：" + payload.length + " 字节");
        }
        writeMsg(A_OPEN, lid, 0, payload, payload.length);
        int rid = 0;
        boolean gotOkay = false;
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        while (true) {
            Msg m = readMsg();
            if (debug) {
                System.out.println("[shell] recv 0x" + Integer.toHexString(m.cmd)
                        + " a0=" + m.arg0 + " a1=" + m.arg1 + " len=" + m.len);
            }
            if (m.cmd == A_OKAY) {
                if (m.arg1 != 0 && m.arg1 != lid) {
                    continue;
                }
                rid = m.arg0;
                gotOkay = true;
                continue;
            }
            if (m.cmd == A_WRTE) {
                if (m.arg1 != 0 && m.arg1 != lid) {
                    continue;
                }
                if (rid == 0) {
                    rid = m.arg0;
                }
                buf.write(m.payload, 0, m.payload.length);
                // 协议要求：收到 WRTE 后回 OKAY 确认（arg0=local, arg1=remote）
                writeMsg(A_OKAY, lid, rid, new byte[0], 0);
                continue;
            }
            if (m.cmd == A_CLSE) {
                if (m.arg1 != 0 && m.arg1 != lid) {
                    continue;   // 上一条流的残留关闭包
                }
                // 回 CLSE 正式关闭流，减少设备重发残留
                try {
                    writeMsg(A_CLSE, lid, m.arg0, new byte[0], 0);
                } catch (IOException ignored) {
                }
                break;
            }
            if (m.cmd == A_AUTH) {
                throw new IOException("连接被要求 ADB 鉴权");
            }
            throw new IOException("shell 阶段意外消息：0x"
                    + Integer.toHexString(m.cmd));
        }
        if (!gotOkay && buf.size() == 0) {
            // 没拿到 OKAY 也没有输出：服务打开失败
            throw new IOException("shell 服务打开失败（无响应）");
        }
        return new String(buf.toByteArray(), "UTF-8");
    }

    // ------------------------------------------------------------ sync 服务（推送文件）

    /** 把字节推送到设备路径（mode 0644）。返回是否成功。 */
    public synchronized boolean push(byte[] data, String remotePath) throws IOException {
        int lid = nextLocal++;
        byte[] openPayload = "sync:\0".getBytes("UTF-8");
        writeMsg(A_OPEN, lid, 0, openPayload, openPayload.length);

        // 等待 OKAY（跳过上一条 shell 流残留的 CLSE/OKAY，否则会误判「服务打开失败」）
        while (true) {
            Msg m = readMsg();
            if (m.cmd == A_OKAY) {
                if (m.arg1 != 0 && m.arg1 != lid) {
                    continue;   // 残留应答，不属于本流
                }
                syncLocal = lid;
                syncRemote = m.arg0;
                break;
            }
            if (m.cmd == A_CLSE) {
                if (m.arg1 != 0 && m.arg1 != lid) {
                    continue;   // 上一条流的残留关闭包
                }
                throw new IOException("sync 服务打开失败");
            }
            throw new IOException("sync 服务打开失败：意外消息 0x"
                    + Integer.toHexString(m.cmd));
        }
        try {
            // SEND 请求：路径 + ",420"（0o644 的十进制）
            String sendPath = remotePath + ",420";
            byte[] pathBytes = sendPath.getBytes("UTF-8");
            byte[] send = new byte[8 + pathBytes.length];
            putTag(send, 0, "SEND");
            putIntLE(send, 4, pathBytes.length);
            System.arraycopy(pathBytes, 0, send, 8, pathBytes.length);
            syncWrite(send);

            // DATA 分块（≤ 64 KB）
            int off = 0;
            while (off < data.length) {
                int n = Math.min(65536, data.length - off);
                byte[] chunk = new byte[8 + n];
                putTag(chunk, 0, "DATA");
                putIntLE(chunk, 4, n);
                System.arraycopy(data, off, chunk, 8, n);
                syncWrite(chunk);
                off += n;
            }
            // DONE + mtime
            byte[] done = new byte[8];
            putTag(done, 0, "DONE");
            putIntLE(done, 4, (int) (System.currentTimeMillis() / 1000));
            syncWrite(done);

            // 读取结果：8 字节 OKAY / FAIL(+len+msg)
            byte[] status = syncRead(8);
            String tag = new String(status, 0, 4, "US-ASCII");
            if (tag.equals("OKAY")) {
                return true;
            }
            if (tag.equals("FAIL")) {
                byte[] lenb = syncRead(4);
                int msgLen = getIntLE(lenb, 0);
                String msg = msgLen > 0 && msgLen < 4096
                        ? new String(syncRead(msgLen), "UTF-8") : "";
                throw new IOException("sync 推送失败: " + msg);
            }
            throw new IOException("sync 未知应答: " + tag);
        } finally {
            try {
                writeMsg(A_CLSE, syncLocal, syncRemote, new byte[0], 0);
            } catch (IOException ignored) {
            }
        }
    }

    /** 握手阶段可能需要等用户在电视上点授权，完成后缩短读超时。 */
    public void setReadTimeout(int ms) {
        try {
            socket.setSoTimeout(ms);
        } catch (java.net.SocketException ignored) {
        }
    }

    private int syncLocal = 0;
    private int syncRemote = 0;
    private byte[] pendingSync = null;

    private void syncWrite(byte[] syncPayload) throws IOException {
        // sync 数据经 WRTE 承载；DATA 分块已控制在 64KB（< 远端 maxdata）
        writeMsg(A_WRTE, syncLocal, syncRemote, syncPayload, syncPayload.length);
        // 每块 WRTE 之后设备会回 OKAY（也可能直接带出 sync 应答）
        while (true) {
            Msg m = readMsg();
            if (m.cmd == A_OKAY) {
                if (m.arg1 != 0 && m.arg1 != syncLocal) continue;
                return;
            }
            if (m.cmd == A_WRTE) {
                if (m.arg1 != 0 && m.arg1 != syncLocal) continue;
                pendingSync = m.payload;
                return;
            }
            if (m.cmd == A_CLSE) {
                if (m.arg1 != 0 && m.arg1 != syncLocal) continue;
                throw new IOException("sync 流被设备提前关闭");
            }
            throw new IOException("sync 写入阶段意外消息：0x" + Integer.toHexString(m.cmd));
        }
    }

    private byte[] syncRead(int n) throws IOException {
        byte[] outBuf = new byte[n];
        int got = 0;
        while (got < n) {
            if (pendingSync != null && pendingSync.length > 0) {
                int take = Math.min(pendingSync.length, n - got);
                System.arraycopy(pendingSync, 0, outBuf, got, take);
                byte[] rest = new byte[pendingSync.length - take];
                System.arraycopy(pendingSync, take, rest, 0, rest.length);
                pendingSync = rest.length > 0 ? rest : null;
                got += take;
                continue;
            }
            Msg m = readMsg();
            if (m.cmd == A_WRTE) {
                if (m.arg1 != 0 && m.arg1 != syncLocal) continue;
                writeMsg(A_OKAY, syncLocal, syncRemote, new byte[0], 0);
                pendingSync = m.payload;
            } else if (m.cmd == A_CLSE) {
                if (m.arg1 != 0 && m.arg1 != syncLocal) continue;
                throw new IOException("sync 流被设备提前关闭");
            } else if (m.cmd == A_OKAY) {
                if (m.arg1 != 0 && m.arg1 != syncLocal) continue;
                continue;
            } else {
                throw new IOException("sync 读取阶段意外消息：0x"
                        + Integer.toHexString(m.cmd));
            }
        }
        return outBuf;
    }

    private static void putTag(byte[] b, int off, String tag) {
        byte[] t = tag.getBytes(java.nio.charset.StandardCharsets.US_ASCII);
        System.arraycopy(t, 0, b, off, 4);
    }

    private static void putIntLE(byte[] b, int off, int v) {
        b[off] = (byte) (v & 0xFF);
        b[off + 1] = (byte) ((v >> 8) & 0xFF);
        b[off + 2] = (byte) ((v >> 16) & 0xFF);
        b[off + 3] = (byte) ((v >> 24) & 0xFF);
    }

    private static int getIntLE(byte[] b, int off) {
        return (b[off] & 0xFF) | ((b[off + 1] & 0xFF) << 8)
                | ((b[off + 2] & 0xFF) << 16) | ((b[off + 3] & 0xFF) << 24);
    }

    // ------------------------------------------------------------ 生命周期

    public boolean isClosed() {
        return closed;
    }

    @Override
    public void close() {
        closed = true;
        try {
            socket.close();
        } catch (IOException ignored) {
        }
    }
}
