package com.pocket.mimonitor;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 全局连接状态与命令调度。
 *
 * ADB 线协议是有状态单通道，所有命令必须串行；Android 又禁止主线程做网络 IO，
 * 因此这里用单线程 Executor 把「连接 / 读状态 / 下发设置」全部排队，
 * 结果通过主线程 Handler 回抛给 UI。
 */
public final class AppState {

    /** 连接成功后回抛给 UI 的状态快照（避免主线程直接读后台线程持有的 Monitor）。 */
    public static class Snapshot {
        public String model;
        public int brightness, mode, source, lightSensor;
        public boolean hdr;
        public final Map<String, Integer> sliders = new HashMap<>();
        public final Map<String, Integer> params = new HashMap<>();

        static Snapshot take(Monitor m) {
            Snapshot s = new Snapshot();
            s.model = m.model;
            s.brightness = m.brightness;
            s.mode = m.mode;
            s.hdr = m.isHdr;
            s.source = m.source;
            s.lightSensor = m.lightSensor;
            s.sliders.putAll(m.sliderValues);
            for (Map.Entry<String, Integer> e : m.paramValues.entrySet()) {
                s.params.put(e.getKey(), e.getValue());
            }
            return s;
        }
    }

    public interface Cb {
        void done(Object result, Exception err);
    }

    public interface Task {
        Object run(Monitor mon) throws Exception;
    }

    private static final String PREF = "pocket_monitor";
    private static final String KEY_IP = "ip";
    private static final String KEY_HDR_MEM_ON = "hdr_mem_on";
    private static final String KEY_HDR_MEM_SDR = "hdr_mem_sdr";
    private static final String KEY_HDR_MEM_HDR = "hdr_mem_hdr";
    /** 出厂默认指向用户当前显示器地址，装好即可自动连；可在设置页修改。 */
    public static final String DEFAULT_IP = "192.168.1.8";

    /** 连接丢失专用异常，UI 据此更新状态栏。 */
    public static class ConnectionLostException extends IOException {
        public ConnectionLostException(String msg) {
            super(msg);
        }
    }

    private static final ExecutorService worker = Executors.newSingleThreadExecutor();
    private static final Handler ui = new Handler(Looper.getMainLooper());

    private static Context app;
    private static AuthKeys keys;
    private static AdbConnection conn;
    private static Monitor mon;
    private static volatile boolean connected = false;
    private static volatile boolean everConnected = false;
    private static String ip = "";
    private static String model = "";

    private AppState() {
    }

    public static void init(Context c) {
        app = c.getApplicationContext();
        ip = prefs().getString(KEY_IP, DEFAULT_IP);
    }

    private static SharedPreferences prefs() {
        return app.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static String getIp() {
        return ip == null || ip.isEmpty() ? DEFAULT_IP : ip;
    }

    public static void setIp(String v) {
        ip = v == null ? "" : v.trim();
        prefs().edit().putString(KEY_IP, ip).apply();
    }

    // ---------------- HDR/SDR 精密控光记忆（对齐桌面版 local_dimming_memory） ----------------

    public static boolean isHdrMemoryEnabled() {
        return prefs().getBoolean(KEY_HDR_MEM_ON, false);
    }

    public static void setHdrMemoryEnabled(boolean on) {
        prefs().edit().putBoolean(KEY_HDR_MEM_ON, on).apply();
    }

    /** 返回记忆的精密控光值 0~3；-1 表示尚未记忆。 */
    public static int getDimmingMemory(boolean hdr) {
        return prefs().getInt(hdr ? KEY_HDR_MEM_HDR : KEY_HDR_MEM_SDR, -1);
    }

    public static void setDimmingMemory(boolean hdr, int v) {
        prefs().edit().putInt(hdr ? KEY_HDR_MEM_HDR : KEY_HDR_MEM_SDR, v).apply();
    }

    public static boolean isConnected() {
        return connected && conn != null && !conn.isClosed();
    }

    /** 是否曾成功连接过（用于判断后台回来后要不要自动重连）。 */
    public static boolean hasEverConnected() {
        return everConnected;
    }

    public static String getModel() {
        return model;
    }

    /** 读取 assets 中内置的 ADB 私钥（与显示器上已授权的公钥配对）。 */
    private static AuthKeys loadKeys() throws IOException {
        if (keys != null) return keys;
        String raw = readAssetText("adb_key.txt");
        if (raw == null || raw.trim().isEmpty()) {
            throw new IOException("APK 缺少内置 ADB 密钥");
        }
        final String fixed = raw.trim();
        keys = new AuthKeys(new AuthKeys.Storage() {
            @Override
            public String loadKeys() {
                return fixed;
            }

            @Override
            public void saveKeys(String both) {
                // 固定密钥：不覆盖
            }
        });
        return keys;
    }

    private static String readAssetText(String name) throws IOException {
        InputStream in = app.getAssets().open(name);
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            return new String(out.toByteArray(), "UTF-8");
        } finally {
            in.close();
        }
    }

    private static Monitor.AssetSource assetSource() {
        return new Monitor.AssetSource() {
            @Override
            public byte[] read(String name) throws IOException {
                InputStream in = app.getAssets().open(name);
                try {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] b = new byte[8192];
                    int n;
                    while ((n = in.read(b)) > 0) out.write(b, 0, n);
                    return out.toByteArray();
                } finally {
                    in.close();
                }
            }
        };
    }

    /** 异步连接（首次授权给 60 秒，成功后把读超时压回 8 秒）。 */
    public static void connect(final String host, final Cb cb) {
        worker.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    disconnectNow();
                    AuthKeys k = loadKeys();
                    AdbConnection c = new AdbConnection(host, 5555, 60000, k);
                    c.setReadTimeout(8000);
                    Monitor m = new Monitor(c, assetSource());
                    m.ensureMtkJar();
                    m.connectAndRead();
                    conn = c;
                    mon = m;
                    model = m.model;
                    connected = true;
                    everConnected = true;
                    setIp(host);
                    finish(cb, Snapshot.take(m), null);
                } catch (java.net.SocketTimeoutException e) {
                    disconnectNow();
                    finish(cb, null, new IOException(
                            "连接超时：显示器无响应。若是首次使用，"
                                    + "请在显示器弹出的「允许 USB 调试吗？」中勾选"
                                    + "「一律允许」并确认后重试"));
                } catch (Exception e) {
                    disconnectNow();
                    finish(cb, null, e);
                }
            }
        });
    }

    /** 判断异常是否为连接层故障（Broken pipe / socket closed / reset 等）。 */
    private static boolean isConnDead(Exception e) {
        if (e instanceof java.net.SocketException) return true;
        if (e instanceof IOException) {
            String msg = e.getMessage();
            if (msg == null) return true;
            String l = msg.toLowerCase();
            return l.contains("broken") || l.contains("closed")
                    || l.contains("reset") || l.contains("pipe")
                    || l.contains("failed to connect");
        }
        return false;
    }

    /** 同步重连（已在 worker 线程上）；超时 15 秒（授权早已完成，无需 60 秒等待）。 */
    private static void reconnectNow() throws Exception {
        disconnectNow();
        AuthKeys k = loadKeys();
        AdbConnection c = new AdbConnection(getIp(), 5555, 15000, k);
        c.setReadTimeout(8000);
        Monitor m = new Monitor(c, assetSource());
        m.ensureMtkJar();
        m.connectAndRead();
        conn = c;
        mon = m;
        model = m.model;
        connected = true;
        everConnected = true;
    }

    /** 异步执行一条命令；连接死掉时自动重连并重试一次。 */
    public static void exec(final Task task, final Cb cb) {
        worker.execute(new Runnable() {
            @Override
            public void run() {
                // 连接已断 → 尝试静默自动重连
                if (!isConnected()) {
                    if (!everConnected) {
                        finish(cb, null, new IOException("尚未连接显示器"));
                        return;
                    }
                    try {
                        reconnectNow();
                    } catch (Exception e) {
                        finish(cb, null, new ConnectionLostException(
                                "连接已断开，请在设置页重新连接"));
                        return;
                    }
                }
                try {
                    finish(cb, task.run(mon), null);
                } catch (Exception e) {
                    if (isConnDead(e)) {
                        // 后台挂久了 socket 假活 → 自动重连 + 重试一次
                        try {
                            reconnectNow();
                            finish(cb, task.run(mon), null);
                        } catch (Exception e2) {
                            disconnectNow();
                            finish(cb, null, new ConnectionLostException(
                                    "连接已断开，请在设置页重新连接"));
                        }
                    } else {
                        if (conn != null && conn.isClosed()) connected = false;
                        finish(cb, null, e);
                    }
                }
            }
        });
    }

    public static void exec(Task task) {
        exec(task, null);
    }

    public static void disconnect(final Cb cb) {
        worker.execute(new Runnable() {
            @Override
            public void run() {
                disconnectNow();
                finish(cb, null, null);
            }
        });
    }

    private static void disconnectNow() {
        connected = false;
        AdbConnection c = conn;
        conn = null;
        mon = null;
        if (c != null) c.close();
    }

    private static void finish(final Cb cb, final Object result, final Exception err) {
        if (cb == null) return;
        ui.post(new Runnable() {
            @Override
            public void run() {
                cb.done(result, err);
            }
        });
    }

    public static void toast(final Context c, final String msg) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                android.widget.Toast.makeText(c, msg,
                        android.widget.Toast.LENGTH_SHORT).show();
            }
        });
    }
}
