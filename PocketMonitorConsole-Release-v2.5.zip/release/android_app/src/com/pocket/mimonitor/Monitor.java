package com.pocket.mimonitor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 红米 G Pro 27U 显示器命令层。
 * 写键方式与桌面版（mtcore/adb.py + monitor_minimal.py）逐条对齐，
 * 保证行为一致：TvService 转发、${IFS} 转义、写键顺序全部复刻。
 */
public class Monitor {

    /** 提供打包进 APK 的 jar 字节（Android 用 AssetManager，桌面测试读文件）。 */
    public interface AssetSource {
        byte[] read(String name) throws IOException;
    }

    public static final String MTK_JAR = "/data/data/mitv.service/cache/MtkDirectTool.jar";
    public static final String LED_JAR = "/data/data/mitv.service/cache/ColorfulLedTool.jar";

    // ---------------- 数据定义（与桌面版一致） ----------------

    public static final int[][] SOURCES = {
            {23}, {24}, {29}, {30},
    };
    public static final String[] SOURCE_NAMES = {"HDMI 1", "HDMI 2", "DP", "USB-C"};

    public static final int[] MODES = {14, 10, 9};
    public static final String[] MODE_NAMES = {"标准", "游戏", "电影"};

    /** 同一组三个模式在 SDR / HDR 信号下各用一套枚举（对齐桌面版 PICTURE_SCENE_NAMES）。 */
    public static final int[] MODE_SDR = {14, 10, 9};
    public static final int[] MODE_HDR = {22, 15, 17};

    /** 桌面版 HDR_TONE_MAPPING_PICTURE_MODES：判定当前图像模式是否属于 HDR。 */
    private static final int[] HDR_MODES = {
            11, 12, 13, 15, 16, 17, 18, 19, 22, 23,
            29, 30, 31, 32, 33, 39, 40, 41, 42, 43, 44
    };

    public static boolean isHdrMode(int v) {
        return inArray(v, HDR_MODES);
    }

    /** 当前模式对应「标准/游戏/电影」哪个槽位；-1 表示不在三模式内。 */
    public static int modeSlot(int v) {
        for (int i = 0; i < MODE_SDR.length; i++) {
            if (MODE_SDR[i] == v || MODE_HDR[i] == v) return i;
        }
        return -1;
    }

    /** 画质参数定义：value/名称成对。 */
    public static final class ParamDef {
        public final String label;
        public final String key;
        public final int[] values;
        public final String[] names;
        ParamDef(String label, String key, int[] values, String[] names) {
            this.label = label; this.key = key; this.values = values; this.names = names;
        }
    }

    public static final ParamDef[] PARAMS = {
            new ParamDef("色温", "picture_color_temperature",
                    new int[]{0, 1, 2, 8, 3},
                    new String[]{"冷色", "标准", "暖色", "原色", "自定义"}),
            new ParamDef("精密控光", "picture_local_dimming",
                    new int[]{0, 1, 2, 3},
                    new String[]{"关", "低", "中", "高"}),
            new ParamDef("HDR 色调映射", "picture_hdr_tone_mapping",
                    new int[]{0, 1, 2, 3},
                    new String[]{"HGiG", "层次", "动态", "明亮"}),
            new ParamDef("动态清晰度", "picture_dynamic_definition",
                    new int[]{0, 1, 2, 3},
                    new String[]{"关", "低", "中", "高"}),
            new ParamDef("灰阶响应时间", "picture_response_time",
                    new int[]{1, 2, 3},
                    new String[]{"普通", "快速", "高速"}),
            new ParamDef("色域", "tv_picture_advanced_video_color_space",
                    new int[]{0, 3, 6, 4, 5, 7},
                    new String[]{"自动", "sRGB", "DCI-P3", "AdobeRGB", "BT2020", "BT709"}),
    };

    // UI 值 ↔ MTK 枚举映射（与桌面版一致）
    private static final int[] HDR_UI_TO_MTK = {5, 0, 2, 1};
    private static final int[] HDR_MTK_TO_UI = reverseMap(HDR_UI_TO_MTK);
    private static final int[] XIAOMI_TO_MTK_TEMP = {1, 2, 3, 0, 0, 0, 0, 0, 6};

    private static int[] reverseMap(int[] fwd) {
        int[] rev = {-1, -1, -1, -1, -1, -1, -1, -1, -1};
        for (int i = 0; i < fwd.length; i++) {
            int v = fwd[i];
            if (v >= 0 && v < rev.length) rev[v] = i;
        }
        return rev;
    }

    private static int mtkHdr(int uiVal) {
        return uiVal >= 0 && uiVal < HDR_UI_TO_MTK.length ? HDR_UI_TO_MTK[uiVal] : 5;
    }

    private static int uiHdr(int mtkVal) {
        return mtkVal >= 0 && mtkVal < HDR_MTK_TO_UI.length ? HDR_MTK_TO_UI[mtkVal] : -1;
    }

    private static int mtkTemp(int xiaomiVal) {
        return xiaomiVal >= 0 && xiaomiVal < XIAOMI_TO_MTK_TEMP.length
                ? XIAOMI_TO_MTK_TEMP[xiaomiVal] : 2;
    }

    // ---------------- TvService 转义（照抄桌面版） ----------------

    private static String tvAppProcess(String jar, String... args) {
        StringBuilder b = new StringBuilder("service call TvService 3 s16 \"sh -c eval\\${IFS}CLASSPATH=");
        b.append(jar)
         .append("\\${IFS}/system/bin/app_process\\${IFS}/data/data/mitv.service/cache");
        for (String a : args) {
            b.append("\\${IFS}").append(a);
        }
        return b.append('"').toString();
    }

    private static String tvShell(String... parts) {
        StringBuilder b = new StringBuilder("service call TvService 3 s16 \"sh -c eval");
        for (String p : parts) {
            b.append("\\${IFS}").append(p);
        }
        return b.append('"').toString();
    }

    // ---------------- 状态 ----------------

    public String model = "";
    public int brightness = 100;
    public int mode = 14;
    public boolean isHdr = false;
    public int source = 23;
    public int lightSensor = 1;
    public final Map<String, Integer> paramValues = new LinkedHashMap<>();
    public final Map<String, Integer> sliderValues = new LinkedHashMap<>();

    // ---------------- 连接与命令 ----------------

    private final AdbConnection conn;
    private final AssetSource assets;

    public Monitor(AdbConnection conn, AssetSource assets) {
        this.conn = conn;
        this.assets = assets;
    }

    public String shell(String cmd) throws IOException {
        return conn.shell(cmd);
    }

    public String get(String k) throws IOException {
        return shell("settings get global " + k).trim();
    }

    public void put(String k, Object v) throws IOException {
        shell("settings put global " + k + " " + v);
    }

    public void key(int keycode) throws IOException {
        shell("input keyevent " + keycode);
    }

    /** 用符号名发按键，与桌面版一致（部分 MiTV 固件对数字键码解析有差异）。 */
    public void key(String keyName) throws IOException {
        shell("input keyevent " + keyName);
    }

    public void refreshPq() throws IOException {
        shell("am broadcast -a com.xiaomi.mitv.action.PIC_MODE_CHANGED --ei picmode 7");
    }

    public String jniSet(String key, Object val, int upd) throws IOException {
        return shell(tvAppProcess(MTK_JAR, "MtkDirectTool", "set", key, String.valueOf(val), String.valueOf(upd)));
    }

    public void hdrToneMapping(int val, int upd) throws IOException {
        shell(tvAppProcess(MTK_JAR, "MtkDirectTool", "setHdrToneMapping",
                String.valueOf(val), String.valueOf(upd)));
    }

    /** 确保 MtkDirectTool.jar 在设备上（大小不符则推送 + cp，与桌面版一致）。 */
    public boolean ensureMtkJar() throws IOException {
        byte[] local = assets.read("MtkDirectTool.jar");
        String sd = "/sdcard/MtkDirectTool.jar";
        String cache = MTK_JAR;
        if (local == null) {
            long sdSize = parseSize(shell(
                    "stat -c %s " + sd + " 2>/dev/null || echo 0"));
            return sdSize >= 1000;
        }
        // 桌面版/上一次已推到缓存路径则直接用，免推送
        long cacheSize = parseSize(shell(
                "stat -c %s " + cache + " 2>/dev/null || echo 0"));
        if (cacheSize == local.length) {
            return true;
        }
        long sdSize = parseSize(shell(
                "stat -c %s " + sd + " 2>/dev/null || echo 0"));
        if (sdSize != local.length) {
            try {
                conn.push(local, sd);
            } catch (IOException e) {
                // sync 通道异常时回退：base64 分块经 shell 写入，保证可推送
                pushViaShell(local, sd);
            }
        }
        shell(tvShell("cp", sd, cache));
        return true;
    }

    /** 回退推送：base64 分块 echo 到临时文件再解码（sync 通道不可用时使用）。 */
    private void pushViaShell(byte[] data, String remotePath) throws IOException {
        String b64 = Base64.getEncoder().encodeToString(data);
        String tmp = remotePath + ".b64";
        shell("rm -f " + tmp);
        int chunk = 3000;
        for (int off = 0; off < b64.length(); off += chunk) {
            String part = b64.substring(off, Math.min(off + chunk, b64.length()));
            shell("echo '" + part + "' >> " + tmp);
        }
        shell("base64 -d " + tmp + " > " + remotePath + " && rm -f " + tmp);
    }

    private static long parseSize(String out) {
        String[] lines = out.trim().split("\n");
        String last = lines.length > 0 ? lines[lines.length - 1].trim() : "0";
        try {
            return Long.parseLong(last);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // ---------------- ADB 保活守护（AdbGuardian，与桌面版同款 APK） ----------------

    public static final String GUARDIAN_PKG = "com.example.adbguardian";
    public static final String GUARDIAN_MAIN = GUARDIAN_PKG + "/.MainActivity";
    public static final String GUARDIAN_A11Y =
            GUARDIAN_PKG + "/" + GUARDIAN_PKG + ".AdbGuardianAccessibilityService";

    /** 一次性批量读取守护状态（单条 shell，避免多次往返）。 */
    public Map<String, String> guardianStatus() throws IOException {
        String raw = shell("echo I=$(pm path " + GUARDIAN_PKG + " 2>/dev/null | head -n1);"
                + "echo P=$(pidof " + GUARDIAN_PKG + " 2>/dev/null);"
                + "echo A=$(settings get global adb_enabled);"
                + "echo W=$(settings get global adb_wifi_enabled);"
                + "echo S=$(getprop service.adb.tcp.port);"
                + "echo R=$(getprop persist.adb.tcp.port);"
                + "echo D=$(getprop init.svc.adbd);"
                + "echo C=$(settings get secure enabled_accessibility_services 2>/dev/null);"
                + "echo M=$(getprop persist.appcontrol_w_mask);"
                + "echo U=$(dumpsys package " + GUARDIAN_PKG
                + " 2>/dev/null | grep 'User 0:' | head -n1)");
        Map<String, String> s = new LinkedHashMap<>();
        for (String line : raw.split("\n")) {
            int i = line.indexOf('=');
            if (i > 0) {
                s.put(line.substring(0, i).trim(), line.substring(i + 1).trim());
            }
        }
        return s;
    }

    /** 守护是否齐全：安装、进程、ADB 开关、端口、辅助功能、休眠保护、非 stopped。 */
    public static boolean guardianOk(Map<String, String> s) {
        return s.getOrDefault("I", "").contains(GUARDIAN_PKG)
                && !s.getOrDefault("P", "").isEmpty()
                && "1".equals(s.get("A"))
                && "1".equals(s.get("W"))
                && "5555".equals(s.get("S"))
                && "5555".equals(s.get("R"))
                && "running".equals(s.get("D"))
                && s.getOrDefault("C", "").contains(GUARDIAN_A11Y)
                && "-134250497".equals(s.get("M"))
                && s.getOrDefault("U", "").contains("stopped=false");
    }

    /** 部署/修复 ADB 保活守护：装 APK → 授权 → 白名单 → 辅助功能 → 启动。 */
    public Map<String, String> ensureGuardian() throws IOException {
        String installed = shell("pm path " + GUARDIAN_PKG + " 2>/dev/null | head -n1").trim();
        if (!installed.contains(GUARDIAN_PKG)) {
            byte[] apk = assets.read("adbguardian-signed.apk");
            if (apk == null) {
                throw new IOException("APK 内缺少 adbguardian-signed.apk");
            }
            // /data/local/tmp 供 installd 读取（/sdcard 在部分固件会被 SELinux 拦）
            String tmp = "/data/local/tmp/adbguardian-signed.apk";
            try {
                conn.push(apk, tmp);
            } catch (IOException e) {
                pushViaShell(apk, tmp);
            }
            String out = shell("pm install -r -d " + tmp);
            if (!out.contains("Success") && out.contains("UPDATE_INCOMPATIBLE")) {
                // 签名冲突（别人装过异版守护）：卸掉重装，全新机器同样适用
                shell("pm uninstall " + GUARDIAN_PKG + " 2>/dev/null || true");
                out = shell("pm install -r -d " + tmp);
            }
            shell("rm -f " + tmp);
            if (!out.contains("Success")) {
                throw new IOException("守护安装失败：" + out.trim());
            }
        }
        shell("pm grant " + GUARDIAN_PKG
                + " android.permission.WRITE_SECURE_SETTINGS 2>/dev/null || true");
        shell("cmd deviceidle whitelist +" + GUARDIAN_PKG + " 2>/dev/null || true");

        String cur = shell("settings get secure enabled_accessibility_services 2>/dev/null").trim();
        String next;
        if (cur.isEmpty() || "null".equals(cur)) {
            next = GUARDIAN_A11Y;
        } else if (cur.contains(GUARDIAN_A11Y)) {
            next = cur;
        } else {
            next = cur + ":" + GUARDIAN_A11Y;
        }
        shell("settings put secure enabled_accessibility_services '" + next + "'");
        shell("settings put secure accessibility_enabled 1");

        shell("am start -n " + GUARDIAN_MAIN + " >/dev/null");
        shell("am broadcast -a " + GUARDIAN_PKG + ".ACTION_KEEP_ALIVE -p "
                + GUARDIAN_PKG + " >/dev/null");
        // 全新安装后进程拉起/掩码写入略有延迟，轮询确认而不是只读一次
        Map<String, String> s = null;
        for (int i = 0; i < 6; i++) {
            s = guardianStatus();
            if (guardianOk(s)) {
                return s;
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
        return s != null ? s : guardianStatus();
    }

    // ---------------- 业务操作（写键顺序与桌面版一致） ----------------

    /** 连接并回读全部状态。 */
    public boolean connectAndRead() throws IOException {
        model = shell("getprop ro.product.model").trim();
        if (model.isEmpty()) {
            throw new IOException("无法读取设备型号（shell 无输出）");
        }
        brightness = clampInt(readInt("picture_backlight", 100), 1, 100);
        mode = readInt("picture_mode", 14);
        if (modeSlot(mode) < 0 && !isHdrMode(mode)) mode = 14;
        isHdr = isHdrMode(mode);
        source = readInt("mitv.tvplayer.hdmi.last.source", 23);
        if (!inArray(source, new int[]{23, 24, 29, 30})) source = 23;
        lightSensor = "1".equals(get("tv_picture_light_sensor").split("\n")[0].trim()) ? 1 : 0;
        paramValues.clear();
        for (ParamDef p : PARAMS) {
            int v = readInt(p.key, Integer.MIN_VALUE);
            if (v == Integer.MIN_VALUE) {
                paramValues.put(p.key, null);
                continue;
            }
            if (p.key.equals("picture_hdr_tone_mapping")) {
                v = uiHdr(v);
            }
            paramValues.put(p.key, v);
        }
        sliderValues.clear();
        sliderValues.put("backlight", brightness);
        sliderValues.put("black_level", readInt("picture_brightness", 50));
        sliderValues.put("contrast", readInt("picture_contrast", 50));
        sliderValues.put("saturation", readInt("picture_saturation", 50));
        sliderValues.put("hue", readInt("picture_hue", 50));
        sliderValues.put("sharpness", readInt("picture_sharpness", 1));
        return true;
    }

    public void setBrightness(int v) throws IOException {
        v = clampInt(v, 1, 100);
        jniSet("g_disp__disp_back_light", v, 3);
        refreshPq();
        put("picture_backlight", v);
        put("xiaomi_picture_backlight", v);
        brightness = v;
    }

    public void setMode(int v) throws IOException {
        put("picture_mode", v);
        refreshPq();
        mode = v;
        isHdr = isHdrMode(v);
    }

    public void setSource(int v) throws IOException {
        shell("am force-stop com.xiaomi.mitv.tvplayer");
        shell("am start -a com.xiaomi.mitv.tvplayer.EXTSRC_PLAY "
                + "-n com.xiaomi.mitv.tvplayer/.ExternalSourceActivity "
                + "--ei input " + v + " -f 0x10000000");
        put("mitv.tvplayer.hdmi.last.source", v);
        refreshPq();
        source = v;
    }

    /** 桌面版 slider_defs 的 name → settings 键名（black_level 特殊）。 */
    private static String sliderKey(String name) {
        if ("black_level".equals(name)) return "picture_brightness";
        return "picture_" + name;
    }

    public void setSlider(String name, int v) throws IOException {
        if ("backlight".equals(name)) {
            jniSet("g_disp__disp_back_light", v, 3);
            refreshPq();
            put("picture_backlight", v);
            put("xiaomi_picture_backlight", v);
        } else {
            put(sliderKey(name), v);
        }
        sliderValues.put(name, v);
    }

    public void setLightSensor(boolean on) throws IOException {
        jniSet("g_video__light_sensor_switch", on ? 1 : 0, 1);
        put("tv_picture_light_sensor", on ? 1 : 0);
        lightSensor = on ? 1 : 0;
    }

    /** 下发一个画质参数（key 为 settings 键名）。 */
    public void setParam(String key, int val) throws IOException {
        if ("picture_color_temperature".equals(key)) {
            jniSet("g_video__clr_temp", mtkTemp(val), 3);
            put(key, val);
        } else if ("picture_local_dimming".equals(key)) {
            jniSet("g_video__vid_local_dimming", val, 3);
            put("picture_local_dimming", val);
            put("tv_picture_video_local_dimming", val);
        } else if ("picture_hdr_tone_mapping".equals(key)) {
            int mtk = mtkHdr(val);
            hdrToneMapping(mtk, 3);
            put("picture_hdr_tone_mapping", mtk);
        } else if ("picture_dynamic_definition".equals(key)) {
            jniSet("g_video__vid_insert_black", val, 3);
            put(key, val);
        } else if ("picture_response_time".equals(key)) {
            jniSet("g_video__vid_od_response_time", val, 3);
            put(key, val);
        } else if ("tv_picture_advanced_video_color_space".equals(key)) {
            jniSet("g_video__vid_gamut_mapping_mode", val, 3);
            put("tv_picture_advanced_video_color_space", val);
            put("tv_picture_video_color_space", val);
        }
        refreshPq();
        paramValues.put(key, val);
    }

    public void power() throws IOException {
        key(26);
    }

    public void volume(int keycode) throws IOException {
        key(keycode);
    }

    // ---------------- 工具 ----------------

    private int readInt(String k, int dflt) {
        try {
            String raw = get(k);
            String[] lines = raw.trim().split("\n");
            String v = lines[lines.length - 1].trim();
            if (v.isEmpty() || "null".equalsIgnoreCase(v)) {
                return dflt;
            }
            return Integer.parseInt(v);
        } catch (Exception e) {
            return dflt;
        }
    }

    private static int clampInt(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static boolean inArray(int v, int[] arr) {
        for (int a : arr) {
            if (a == v) return true;
        }
        return false;
    }

    /** 找到 key 对应的参数定义。 */
    public static ParamDef paramDef(String key) {
        for (ParamDef p : PARAMS) {
            if (p.key.equals(key)) return p;
        }
        return null;
    }

    /** 找到参数值对应的显示名。 */
    public static String paramOptionName(String key, int val) {
        ParamDef p = paramDef(key);
        if (p == null) return String.valueOf(val);
        for (int i = 0; i < p.values.length; i++) {
            if (p.values[i] == val) return p.names[i];
        }
        return String.valueOf(val);
    }

    public static String sourceName(int v) {
        int[][] pairs = {{23, 0}, {24, 1}, {29, 2}, {30, 3}};
        for (int[] p : pairs) {
            if (p[0] == v) return SOURCE_NAMES[p[1]];
        }
        return String.valueOf(v);
    }

    public static String modeName(int v) {
        for (int i = 0; i < MODES.length; i++) {
            if (MODES[i] == v) return MODE_NAMES[i];
        }
        return "未知";
    }
}
