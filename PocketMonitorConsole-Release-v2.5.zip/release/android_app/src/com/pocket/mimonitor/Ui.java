package com.pocket.mimonitor;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/** 纯代码构建 UI 的小工具（对齐桌面版深色 + 橙 #F2622F 风格）。 */
public final class Ui {

    public static final int BG = Color.parseColor("#101216");
    public static final int CARD = Color.parseColor("#1B1E24");
    public static final int CARD_ALT = Color.parseColor("#242830");
    public static final int ACCENT = Color.parseColor("#F2622F");
    public static final int TEXT = Color.parseColor("#F3F4F6");
    public static final int SUB = Color.parseColor("#8C929D");
    public static final int LINE = Color.parseColor("#2C3038");

    private Ui() {
    }

    public static int dp(Context c, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics());
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable d = new GradientDrawable();
        d.setColor(CARD);
        d.setCornerRadius(dp(c, 18));
        l.setBackground(d);
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        return l;
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static TextView title(Context c, String s) {
        return text(c, s, 15, TEXT, true);
    }

    public static TextView hint(Context c, String s) {
        return text(c, s, 12, SUB, false);
    }

    /** 竖向页面容器（ScrollView 里的 LinearLayout）。 */
    public static LinearLayout page(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = dp(c, 14);
        l.setPadding(p, dp(c, 6), p, dp(c, 20));
        return l;
    }

    public static LinearLayout.LayoutParams cardLp(Context c) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(c, 12);
        return lp;
    }

    public static void setCorner(View v, int color, int radiusPx) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusPx);
        v.setBackground(d);
    }

    /** 胶囊按钮；选中态深橙底白字，未选中深灰底浅字。 */
    public static TextView chip(Context c, String label, boolean selected) {
        TextView t = new TextView(c);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setIncludeFontPadding(false);
        t.setTypeface(selected ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        t.setTextColor(selected ? Color.WHITE : SUB);
        t.setPadding(dp(c, 12), dp(c, 9), dp(c, 12), dp(c, 9));
        t.setMinWidth(dp(c, 62));
        t.setMinHeight(dp(c, 36));   // 选中加粗后高度不跳变
        setCorner(t, selected ? ACCENT : CARD_ALT, dp(c, 11));
        return t;
    }

    /** 一排胶囊；返回容器，调用方负责给每个 child 设点击监听。 */
    public static LinearLayout chipRow(Context c, String[] labels, int selectedIndex) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < labels.length; i++) {
            TextView chip = chip(c, labels[i], i == selectedIndex);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            lp.rightMargin = i == labels.length - 1 ? 0 : dp(c, 8);
            row.addView(chip, lp);
        }
        return row;
    }

    /** 多行胶囊容器（每行 perRow 个，解决 5~6 个选项挤在一行的问题）。 */
    public static LinearLayout chipGrid(Context c, String[] labels,
                                        int selectedIndex, int perRow) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = null;
        for (int i = 0; i < labels.length; i++) {
            if (i % perRow == 0) {
                row = new LinearLayout(c);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT);
                if (i > 0) rlp.topMargin = dp(c, 8);
                box.addView(row, rlp);
            }
            TextView chip = chip(c, labels[i], i == selectedIndex);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            // 边距只看列位置：最后一列（含占位）不带右边距，保证每行列宽一致
            lp.rightMargin = (i % perRow == perRow - 1) ? 0 : dp(c, 8);
            row.addView(chip, lp);
        }
        // 补齐最后一行的空位（占位与真实格子同边距，保证等宽不错位）
        if (row != null) {
            int filled = labels.length % perRow;
            if (filled != 0) {
                for (int k = filled; k < perRow; k++) {
                    View spacer = new View(c);
                    LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                            0, 1, 1);
                    slp.rightMargin = (k == perRow - 1) ? 0 : dp(c, 8);
                    row.addView(spacer, slp);
                }
            }
        }
        return box;
    }

    /** 带标题与数值的滑杆卡片。 */
    public static LinearLayout sliderCard(Context c, String label, int min, int max,
                                          int value, SeekBar.OnSeekBarChangeListener cb) {
        LinearLayout card = card(c);
        card.setClipToPadding(false);   // 允许滑块圆点画进卡片内边距，极值不被裁
        LinearLayout head = new LinearLayout(c);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = title(c, label);
        head.addView(name, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        final TextView val = text(c, String.valueOf(value), 14, ACCENT, true);
        head.addView(val);
        card.addView(head);

        SeekBar bar = new SeekBar(c);
        bar.setMax(max - min);
        bar.setProgress(value - min);
        int thumbPad = dp(c, 14);
        bar.setPadding(thumbPad, dp(c, 12), thumbPad, dp(c, 2));
        bar.setThumbTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        bar.setProgressBackgroundTintList(
                android.content.res.ColorStateList.valueOf(LINE));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                val.setText(String.valueOf(p + min));
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
                if (cb != null) cb.onStartTrackingTouch(s);
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                if (cb != null) cb.onStopTrackingTouch(s);
            }
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.leftMargin = -thumbPad;    // 抵消滑块留白，轨道与文字左右对齐
        blp.rightMargin = -thumbPad;
        card.addView(bar, blp);
        card.setTag(bar);
        return card;
    }

    public static SeekBar barOf(LinearLayout card) {
        Object o = card.getTag();
        return o instanceof SeekBar ? (SeekBar) o : null;
    }

    public static TextView bigButton(Context c, String label, boolean primary) {
        TextView t = text(c, label, 15, primary ? Color.WHITE : TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 12), dp(c, 15), dp(c, 12), dp(c, 15));
        setCorner(t, primary ? ACCENT : CARD_ALT, dp(c, 14));
        return t;
    }

    public static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(LINE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 1)));
        lp.topMargin = dp(c, 12);
        lp.bottomMargin = dp(c, 12);
        v.setLayoutParams(lp);
        return v;
    }
}
