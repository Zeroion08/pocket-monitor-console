package com.pocket.mimonitor;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

/**
 * 桌面 JVM 测试入口（不打入 APK）：
 * 用真实显示器 5555 端口验证 ADB 协议实现与命令层。
 * 用法：java com.pocket.mimonitor.DesktopTest <ip> [brightness]
 */
public class DesktopTest {
    public static void main(String[] args) throws Exception {
        AdbConnection.debug = System.getenv("ADB_DEBUG") != null;
        String ip = args.length > 0 ? args[0] : "";
        if (ip.isEmpty()) {
            System.out.println("用法: DesktopTest <显示器IP> [新亮度1-100]");
            return;
        }
        File jarDir = new File("../minimal_ui/assets/runtime");
        Monitor.AssetSource assets = new Monitor.AssetSource() {
            @Override
            public byte[] read(String name) throws IOException {
                File f = new File(jarDir, name);
                return f.exists() ? Files.readAllBytes(f.toPath()) : null;
            }
        };

        System.out.println("== 1. 连接 " + ip + ":5555 ==");
        java.nio.file.Path keyFile = new java.io.File("adb_key.txt").toPath();
        AuthKeys keys = new AuthKeys(new AuthKeys.Storage() {
            @Override
            public String loadKeys() {
                try {
                    return java.nio.file.Files.exists(keyFile)
                            ? new String(java.nio.file.Files.readAllBytes(keyFile),
                                    "UTF-8") : null;
                } catch (IOException e) {
                    return null;
                }
            }

            @Override
            public void saveKeys(String both) {
                try {
                    java.nio.file.Files.write(keyFile, both.getBytes("UTF-8"));
                } catch (IOException ignored) {
                }
            }
        });
        try (AdbConnection conn = new AdbConnection(ip, 5555, 6000, keys)) {
            System.out.println("握手成功");

            Monitor mon = new Monitor(conn, assets);

            System.out.println("\n== 2. shell: getprop ro.product.model ==");
            String model = mon.shell("getprop ro.product.model");
            System.out.println("model = " + model.trim());

            System.out.println("\n== 3. ensureMtkJar（含 stat/推送/cp）==");
            boolean jarOk = mon.ensureMtkJar();
            System.out.println("jar ready = " + jarOk);

            System.out.println("\n== 4. 读状态 ==");
            System.out.println("backlight = " + mon.get("picture_backlight").trim());
            System.out.println("picture_mode = " + mon.get("picture_mode").trim());
            System.out.println("source = " + mon.get("mitv.tvplayer.hdmi.last.source").trim());
            System.out.println("contrast = " + mon.get("picture_contrast").trim());

            if (args.length > 1) {
                int v = Integer.parseInt(args[1]);
                System.out.println("\n== 5. 设置亮度 = " + v + " ==");
                mon.setBrightness(v);
                System.out.println("已下发，回读 = " + mon.get("picture_backlight").trim());
            }

            System.out.println("\n== 6. jni_set 空跑验证（色温写当前值）==");
            try {
                int cur = Integer.parseInt(
                        mon.get("picture_color_temperature").trim().split("\n")[0].trim());
                mon.setParam("picture_color_temperature", cur);
                System.out.println("jni_set OK（色温 = " + cur + "）");
            } catch (Exception e) {
                System.out.println("jni_set 失败: " + e.getMessage());
            }

            System.out.println("\n== 7. push 测试（推送一个小文件到 /sdcard）==");
            byte[] payload = "pocket-console sync test".getBytes("UTF-8");
            boolean ok = conn.push(payload, "/sdcard/.pocket_sync_test");
            System.out.println("push = " + ok);
            System.out.println("回读 = " + mon.shell(
                    "cat /sdcard/.pocket_sync_test 2>/dev/null; rm -f /sdcard/.pocket_sync_test").trim());
        }
        System.out.println("\n全部通过 ✅");
    }
}
