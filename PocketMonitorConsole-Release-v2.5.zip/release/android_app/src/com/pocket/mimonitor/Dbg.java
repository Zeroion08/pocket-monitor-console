package com.pocket.mimonitor;
import java.nio.file.*;
public class Dbg {
    public static void main(String[] a) throws Exception {
        AdbConnection.debug = true;
        Path kf = Paths.get("adb_key.txt");
        AuthKeys keys = new AuthKeys(new AuthKeys.Storage() {
            public String loadKeys() { try { return Files.exists(kf) ? new String(Files.readAllBytes(kf), "UTF-8") : null; } catch (Exception e) { return null; } }
            public void saveKeys(String s) {}
        });
        System.out.println("connecting...");
        try (AdbConnection c = new AdbConnection("192.168.1.8", 5555, 8000, keys)) {
            System.out.println("AUTHED!");
            System.out.println("model=" + c.shell("getprop ro.product.model").trim());
        }
    }
}
