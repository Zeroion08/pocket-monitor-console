package com.pocket.mimonitor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Base64;

/**
 * ADB RSA 认证密钥：对齐 AOSP adb 客户端的行为。
 * - signToken：adbd 用 RSA_sign(NID_sha1, token, 20) 签名、RSA_verify(NID_sha1,
 *   token, 20) 验签——token 被**直接当作 SHA1 digest**，不重新哈希。所以这里
 *   手工构造 PKCS#1 v1.5 块（DigestInfo(SHA1) + token）后用 NoPadding 模幂，
 *   不能用 SHA1withRSA / SHA256withRSA（它们会对 token 再做一次哈希）。
 * - androidPublicKey：AOSP RSAPublicKey 结构体（len/n0inv/n/rr/exponent，
 *   小端）base64 + "\0"，即 adbd 期望的 AUTH RSAPUBLICKEY 载荷
 */
public class AuthKeys {

    private PrivateKey privateKey;
    private PublicKey publicKey;

    /** 密钥字节存储（Android 用 SharedPreferences，桌面测试用文件）。 */
    public interface Storage {
        String loadKeys();              // "privB64 pubB64"，无则 null
        void saveKeys(String both);
    }

    public AuthKeys(Storage storage) throws IOException {
        String saved = storage.loadKeys();
        if (saved != null) {
            try {
                String[] parts = saved.trim().split("\\s+");
                byte[] privDer = Base64.getDecoder().decode(parts[0]);
                byte[] pubDer = Base64.getDecoder().decode(parts[1]);
                KeyFactory kf = KeyFactory.getInstance("RSA");
                privateKey = kf.generatePrivate(new PKCS8EncodedKeySpec(privDer));
                publicKey = kf.generatePublic(new X509EncodedKeySpec(pubDer));
                return;
            } catch (Exception e) {
                // 密钥损坏：重新生成
            }
        }
        try {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
            kpg.initialize(2048, new SecureRandom());
            KeyPair kp = kpg.generateKeyPair();
            privateKey = kp.getPrivate();
            publicKey = kp.getPublic();
            storage.saveKeys(Base64.getEncoder().encodeToString(privateKey.getEncoded())
                    + " " + Base64.getEncoder().encodeToString(publicKey.getEncoded()));
        } catch (Exception e) {
            throw new IOException("生成 ADB 密钥失败: " + e);
        }
    }

    /** 导出（私钥 base64 + 空格 + 公钥 base64），用于预生成密钥场景。 */
    public String exportKeys() {
        return Base64.getEncoder().encodeToString(privateKey.getEncoded())
                + " " + Base64.getEncoder().encodeToString(publicKey.getEncoded());
    }

    /**
     * 对 adbd 的 20 字节 token 生成 ADB AUTH SIGNATURE。
     *
     * AOSP: RSA_sign(NID_sha1, token, 20, sig, ...) —— 把 token 当作 SHA1
     * digest，构造 PKCS#1 v1.5 编码块 EM = 00 01 FF..FF 00 || DigestInfo
     * 后做私钥模幂。Java 标准 Signature 无法跳过哈希，故手工实现。
     */
    public byte[] signToken(byte[] token) {
        try {
            int keyBits = 2048;
            int emLen = keyBits / 8;                      // 256
            // DigestInfo for SHA1: SEQ(0x21) { AlgorithmId(SHA1)+NULL, OCTET STRING(20) }
            byte[] digestInfo = {
                    0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e,
                    0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
            };
            byte[] digest = token.length >= 20
                    ? Arrays.copyOf(token, 20) : Arrays.copyOf(token, 20);
            byte[] t = new byte[digestInfo.length + 20];
            System.arraycopy(digestInfo, 0, t, 0, digestInfo.length);
            System.arraycopy(digest, 0, t, digestInfo.length, 20);

            byte[] em = new byte[emLen];
            em[0] = 0x00;
            em[1] = 0x01;
            int psLen = emLen - t.length - 3;
            Arrays.fill(em, 2, 2 + psLen, (byte) 0xFF);
            em[2 + psLen] = 0x00;
            System.arraycopy(t, 0, em, 3 + psLen, t.length);

            javax.crypto.Cipher cipher =
                    javax.crypto.Cipher.getInstance("RSA/ECB/NoPadding");
            cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, privateKey);
            return cipher.doFinal(em);
        } catch (Exception e) {
            return null;
        }
    }

    /** AOSP 公钥格式：len(4) n0inv(4) n(256) rr(256) exponent(4)，全部小端。 */
    public byte[] androidPublicKeyPayload() throws IOException {
        try {
            RSAPublicKeySpec spec = (RSAPublicKeySpec) KeyFactory
                    .getInstance("RSA").getKeySpec(publicKey, RSAPublicKeySpec.class);
            BigInteger n = spec.getModulus();
            BigInteger e = spec.getPublicExponent();
            BigInteger m32 = BigInteger.TWO.pow(32);
            BigInteger n0inv = n.mod(m32).modInverse(m32).negate().mod(m32);
            BigInteger rr = BigInteger.TWO.pow(2048).modPow(BigInteger.TWO, n);

            ByteArrayOutputStream out = new ByteArrayOutputStream(524);
            writeIntLE(out, 64);                       // len: 2048/32 words
            writeIntLE(out, n0inv.intValue());
            writeFixedLE(out, n.toByteArray(), 256);   // modulus
            writeFixedLE(out, rr.toByteArray(), 256);  // R^2 mod n
            writeIntLE(out, e.intValue());

            String b64 = Base64.getEncoder().encodeToString(out.toByteArray());
            return (b64 + "\0").getBytes("UTF-8");
        } catch (Exception ex) {
            throw new IOException("构造 ADB 公钥失败: " + ex);
        }
    }

    /** 公钥的 base64（不含 \0），用于预授权写入设备 adb_keys。 */
    public String androidPublicKeyBase64() throws IOException {
        byte[] payload = androidPublicKeyPayload();
        String s = new String(payload, "UTF-8");
        return s.trim();
    }

    private static void writeIntLE(ByteArrayOutputStream out, int v) {
        out.write(v & 0xFF);
        out.write((v >> 8) & 0xFF);
        out.write((v >> 16) & 0xFF);
        out.write((v >> 24) & 0xFF);
    }

    private static void writeFixedLE(ByteArrayOutputStream out, byte[] bigEndianBytes, int len) {
        // BigInteger.toByteArray() 是大端、可能带符号前导 0——转成小端定长
        byte[] be = Arrays.copyOfRange(bigEndianBytes,
                Math.max(0, bigEndianBytes.length - len), bigEndianBytes.length);
        if (be.length < len) {
            byte[] pad = new byte[len];
            System.arraycopy(be, 0, pad, len - be.length, be.length);
            be = pad;
        }
        for (int i = len - 1; i >= 0; i--) {
            out.write(be[i] & 0xFF);
        }
    }
}
