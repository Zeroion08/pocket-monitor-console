package com.pocket.mimonitor;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * 桌面工具（不打入 APK）：生成 App 专用 ADB 密钥并导出公钥，
 * 供预授权写入显示器 adb_keys 使用。
 */
public class PrepKey {
    public static void main(String[] args) throws Exception {
        Path keyFile = Paths.get("adb_key.txt");
        AuthKeys.Storage storage = new AuthKeys.Storage() {
            @Override
            public String loadKeys() {
                try {
                    return Files.exists(keyFile)
                            ? new String(Files.readAllBytes(keyFile), StandardCharsets.UTF_8)
                            : null;
                } catch (IOException e) {
                    return null;
                }
            }

            @Override
            public void saveKeys(String both) {
                try {
                    Files.write(keyFile, both.getBytes(StandardCharsets.UTF_8));
                } catch (IOException ignored) {
                }
            }
        };
        AuthKeys keys = new AuthKeys(storage);
        System.out.println("keys file: " + keyFile.toAbsolutePath());
        System.out.println("export: " + keys.exportKeys().substring(0, 40) + "...");
        // 公钥写成单独文件（不含 \0，可直接 >> adb_keys）
        Path pubFile = Paths.get("adb_key_pub.b64");
        Files.write(pubFile, (keys.androidPublicKeyBase64() + "\n")
                .getBytes(StandardCharsets.UTF_8));
        System.out.println("pubkey file: " + pubFile.toAbsolutePath());
        System.out.println("pubkey len: " + keys.androidPublicKeyBase64().length());
    }
}
